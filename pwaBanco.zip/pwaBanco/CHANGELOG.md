# Changelog

## [Unreleased]
### Added
- API de cámara (getUserMedia) en la página de push y características nativas

## [1.1.0] - 2026-06-11
### Added
- Security utilities module
- REST API endpoints v1
- Enhanced dashboard UI
- Extended .gitignore and .gitattributes
### Fixed
- Minor CSS improvements

## [1.0.0] - 2026-06-12
### Added
- Initial release of BancoMéxico Finance extension support
- Dashboard integration
- Client segmentation tools
- Campaign management
