# 🚀 BancoFinancesChat - Guía Rápida de Ejecución

**Sistema de Segmentación de Clientes con IA**

---

## ⚡ INICIO RÁPIDO SIN DOCKER (Desarrollo Local)

### Paso 1: Instalar dependencias
```bash
cd app
pip install --break-system-packages -r requirements.txt
```

### Paso 2: Ejecutar la aplicación
```bash
python app.py
```

### ✅ Si todo funciona correctamente, verás:
```
[OK] FinancuerAI configurado correctamente — IA gratuita integrada
 * Running on http://127.0.0.1:5000
```

### 🌐 Accede a la aplicación
Abre en tu navegador: **http://localhost:5000**

---

## 🐳 EJECUCIÓN CON DOCKER (Producción)

### Paso 1: Asegúrate que Docker esté instalado
```bash
docker --version
docker-compose --version
```

### Paso 2: Construir y ejecutar
```bash
# Desde la raíz del proyecto
docker-compose up --build
```

### ✅ Si todo funciona correctamente, verás:
```
flask_app  | [OK] FinancuerAI configurado correctamente
nginx      | [info] Nginx is running
```

### 🌐 Accede a la aplicación
Abre en tu navegador: **http://localhost**

---

## 📋 CREDENCIALES DE ACCESO

| Usuario | Contraseña | Rol |
|---------|-----------|-----|
| admin@banconexus.mx | nexus2024 | Administrador |
| ana@banconexus.mx | analista123 | Analista |

---

## 🛑 DETENER LA APLICACIÓN

### Sin Docker:
```bash
Presiona CTRL + C en la terminal
```

### Con Docker:
```bash
docker-compose down
```

---

## ⚙️ SOLUCIÓN DE PROBLEMAS

### Error: "Module not found"
```bash
pip install --break-system-packages -r requirements.txt
```

### Error: "Port 5000 already in use"
```bash
# Cambiar puerto en app.py línea 800
app.run(debug=True, port=5001)  # Cambiar a otro puerto
```

### Error: "Database locked"
```bash
# Eliminar base de datos anterior
rm -rf app/instance/bancofinanciero.db
python app.py
```

---

## 📊 CARACTERÍSTICAS

- ✅ Segmentación inteligente de clientes
- ✅ IA gratuita integrada (FinancuerAI)
- ✅ Dashboard en tiempo real
- ✅ Análisis de riesgo de abandono
- ✅ Gestión de campañas
- ✅ Autenticación segura
- ✅ Base de datos SQLite
- ✅ Interfaz responsiva

---

## 📞 SOPORTE

Para más información, revisa:
- `README.md` - Documentación completa
- `docker-compose.yml` - Configuración de servicios
- `app/app.py` - Código de la aplicación

---

**Desarrollado por:** Guerrero Villanueva Noemi Judith  
**Versión:** 1.0.0  
**Estado:** Producción lista
