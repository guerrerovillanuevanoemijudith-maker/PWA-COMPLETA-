"""Pruebas de la opción "Descargar aplicación".
Autora: Noemi Judith Guerrero Villanueva · Matrícula 202204010
"""
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as modulo  # noqa: E402


@pytest.fixture()
def cliente():
    modulo.app.config["TESTING"] = True
    with modulo.app.test_client() as c:
        yield c


def test_script_descargar_se_sirve(cliente):
    r = cliente.get("/static/js/descargar-app.js")
    assert r.status_code == 200 and b"beforeinstallprompt" in r.data


def test_inicio_enlaza_el_script(cliente):
    assert b"descargar-app.js" in cliente.get("/inicio").data


def test_login_enlaza_el_script(cliente):
    assert b"descargar-app.js" in cliente.get("/login").data
