"""Pruebas de extremo a extremo en un navegador real (Chromium con Playwright).
Verifica en el DESTINO (local o la URL publicada) que la PWA es instalable,
funciona sin conexión y recibe notificaciones.

Uso:
    pip install -r requirements-dev.txt && python -m playwright install chromium
    python tests/e2e_navegador.py                      # contra http://localhost:8000
    python tests/e2e_navegador.py https://MI-APP.onrender.com
    CAPTURAS=capturas python tests/e2e_navegador.py    # además guarda capturas

Autora: Noemi Judith Guerrero Villanueva · Matrícula 202204010
"""
import json
import os
import sys
import time

from playwright.sync_api import sync_playwright

URL = (sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000").rstrip("/")
CAPTURAS = os.environ.get("CAPTURAS")
EMAIL = os.environ.get("PWA_EMAIL", "admin@bancomexicofinance.mx")
CLAVE = os.environ.get("PWA_CLAVE", "nexus2024")
resultados = []


def verificar(nombre, ok, detalle=""):
    resultados.append({"prueba": nombre, "resultado": "APROBADA" if ok else "FALLÓ", "detalle": detalle})
    print(("[OK]   " if ok else "[FALLO] ") + nombre + (" -> " + str(detalle) if detalle else ""))


def captura(page, nombre):
    if CAPTURAS:
        os.makedirs(CAPTURAS, exist_ok=True)
        page.screenshot(path=os.path.join(CAPTURAS, nombre + ".png"))


with sync_playwright() as p:
    # "chromium" = nuevo modo headless de Chrome, el único que soporta permisos de notificaciones
    try:
        nav = p.chromium.launch(channel="chromium")
    except Exception:
        nav = p.chromium.launch()
    ctx = nav.new_context(viewport={"width": 1280, "height": 800}, locale="es-MX")
    ctx.grant_permissions(["notifications"], origin=URL)
    page = ctx.new_page()
    cdp = ctx.new_cdp_session(page)

    # ── 1. HTTPS y manifiesto ──────────────────────────────────────────────
    verificar("Contexto seguro (HTTPS o localhost)", URL.startswith("https://") or "localhost" in URL or "127.0.0.1" in URL, URL)
    page.goto(URL + "/splash")
    captura(page, "01_splash")
    page.wait_for_url("**/inicio", timeout=8000)
    page.wait_for_load_state("networkidle")
    captura(page, "02_inicio_sin_sesion")
    man = json.loads(page.evaluate("fetch('/manifest.json').then(r => r.text())"))
    ok = all(man.get(k) for k in ("name", "short_name", "start_url", "display", "icons")) and man["display"] == "standalone"
    verificar("Manifiesto con nombre, start_url, display standalone e iconos", ok, man.get("start_url"))
    tam = {i["sizes"] for i in man["icons"]}
    verificar("Iconos de 192 y 512 px", {"192x192", "512x512"} <= tam, sorted(tam))

    # ── 2. Service Worker ──────────────────────────────────────────────────
    page.evaluate("navigator.serviceWorker.ready.then(() => true)")
    page.reload(); page.wait_for_load_state("networkidle")
    controla = page.evaluate("!!navigator.serviceWorker.controller")
    verificar("Service Worker activo y controlando la página", controla)
    n_cache = page.evaluate("caches.keys().then(ks => Promise.all(ks.map(k => caches.open(k).then(c => c.keys())))).then(l => l.reduce((a,b)=>a+b.length,0))")
    verificar("App Shell precargado en caché", n_cache >= 8, str(n_cache) + " archivos")

    # ── 3. Instalabilidad (criterios de Chrome) ────────────────────────────
    try:
        cdp.send("Page.enable")
        err = cdp.send("Page.getInstallabilityErrors").get("installabilityErrors", [])
        # "in-incognito" lo causa el contexto de prueba (Playwright abre un perfil incógnito),
        # no la app; en un Chrome normal ese error no aparece.
        err = [e for e in err if e["errorId"] != "in-incognito"]
        verificar("Chrome no reporta errores de instalabilidad", len(err) == 0, [e["errorId"] for e in err])
    except Exception as e:
        verificar("Chrome no reporta errores de instalabilidad", False, str(e)[:120])

    # ── 4. Login y vistas SSR / CSR (calienta la caché) ───────────────────
    page.goto(URL + "/login")
    page.fill("input[name=email]", EMAIL)
    page.fill("input[name=password]", CLAVE)
    page.click("button[type=submit]")
    page.wait_for_url("**/dashboard", timeout=8000)
    page.wait_for_load_state("networkidle")
    verificar("Inicio de sesión y vista SSR (/dashboard)", "/dashboard" in page.url)
    captura(page, "03_dashboard_ssr")
    page.goto(URL + "/dashboard-csr")
    page.wait_for_selector(".kpi-card, .stat-card, #csr-root *", timeout=8000)
    page.wait_for_timeout(1500)
    verificar("Vista CSR arma el contenido en el navegador", page.locator("#csr-root").inner_text().strip() != "")
    captura(page, "04_dashboard_csr")
    page.goto(URL + "/clientes"); page.wait_for_load_state("networkidle")
    page.goto(URL + "/inicio"); page.wait_for_load_state("networkidle")
    page.wait_for_selector("#kpis .kpi", timeout=8000)
    verificar("Módulo de datos: KPIs desde el servidor", "(actualizado ahora)" in page.inner_text("#origenDatos"))
    captura(page, "05_inicio_con_datos")

    # ── 5. Funcionamiento offline ──────────────────────────────────────────
    ctx.set_offline(True)
    page.goto(URL + "/dashboard-csr")
    page.wait_for_timeout(1500)
    cuerpo = page.locator("#csr-root").inner_text().strip()
    verificar("Offline: la vista CSR abre desde caché con sus datos", cuerpo != "" and "No se pudieron" not in cuerpo)
    captura(page, "06_offline_dashboard_csr")
    page.goto(URL + "/inicio")
    page.wait_for_selector("#kpis .kpi", timeout=8000)
    page.wait_for_timeout(500)
    verificar("Offline: pantalla de inicio con aviso de conexión", page.locator("#bannerRed").is_visible())
    verificar("Offline: datos guardados en IndexedDB", "dispositivo" in page.inner_text("#origenDatos"), page.inner_text("#origenDatos"))
    captura(page, "07_offline_inicio")
    page.goto(URL + "/campanas/nueva")  # ruta no visitada antes
    page.wait_for_timeout(800)
    verificar("Offline: ruta no visitada muestra la página /offline", "sin conexión" in page.content().lower())
    captura(page, "08_offline_pagina_respaldo")
    ctx.set_offline(False)

    # ── 6. Notificaciones ──────────────────────────────────────────────────
    page.goto(URL + "/notificaciones-nativas"); page.wait_for_load_state("networkidle")
    page.click("#btnPermiso"); page.wait_for_timeout(500)
    page.click("#btnLocal"); page.wait_for_timeout(1200)
    activas = page.evaluate("navigator.serviceWorker.ready.then(r => r.getNotifications()).then(n => n.length)")
    verificar("Notificación local mostrada por el Service Worker", activas >= 1, str(activas) + " activa(s)")
    captura(page, "09_notificaciones_local")

    # Entrega de un evento push real al Service Worker (DevTools Protocol)
    cdp.send("ServiceWorker.enable")
    regs = []
    cdp.on("ServiceWorker.workerRegistrationUpdated", lambda e: regs.extend(e.get("registrations", [])))
    page.reload(); page.wait_for_timeout(1500)
    page.evaluate("navigator.serviceWorker.ready.then(r => r.getNotifications()).then(l => l.forEach(n => n.close()))")
    if regs:
        cdp.send("ServiceWorker.deliverPushMessage", {
            "origin": URL, "registrationId": regs[-1]["registrationId"],
            "data": json.dumps({"title": "FinancePWA · Prueba push", "body": "Evento push entregado al Service Worker", "url": "/inicio"}),
        })
        time.sleep(1.5)
        n = page.evaluate("navigator.serviceWorker.ready.then(r => r.getNotifications()).then(l => l.map(x => x.title))")
        verificar("Evento push recibido y notificación mostrada", any("Prueba push" in t for t in n), n)
    else:
        verificar("Evento push recibido y notificación mostrada", False, "sin registro de SW")
    captura(page, "10_push_entregado")

    nav.close()

fallos = [r for r in resultados if r["resultado"] != "APROBADA"]
if os.environ.get("REPORTE_JSON"):
    with open(os.environ["REPORTE_JSON"], "w", encoding="utf-8") as f:
        json.dump(resultados, f, ensure_ascii=False, indent=2)
print("\nTotal: %d pruebas, %d aprobadas, %d fallidas" % (len(resultados), len(resultados) - len(fallos), len(fallos)))
sys.exit(1 if fallos else 0)
