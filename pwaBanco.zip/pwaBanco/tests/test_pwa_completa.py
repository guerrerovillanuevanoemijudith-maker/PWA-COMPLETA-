"""Pruebas automáticas de la PWA (cliente de pruebas de Flask).
Ejecutar:  python -m pytest tests -v
Autora: Noemi Judith Guerrero Villanueva · Matrícula 202204010
"""
import json
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import app as modulo  # noqa: E402


@pytest.fixture()
def cliente():
    modulo.app.config["TESTING"] = True
    with modulo.app.test_client() as c:
        yield c


@pytest.fixture()
def sesion(cliente):
    with cliente.session_transaction() as s:
        s["user_id"] = 1
        s["user_nombre"] = "Admin"
        s["user_rol"] = "admin"
    return cliente


def test_salud(cliente):
    r = cliente.get("/health")
    assert r.status_code == 200 and r.get_json()["status"] == "ok"


def test_inicio_y_splash_son_publicos(cliente):
    assert cliente.get("/inicio").status_code == 200
    assert cliente.get("/splash").status_code == 200
    assert cliente.get("/offline").status_code == 200


def test_raiz_redirige_a_login(cliente):
    assert cliente.get("/").status_code == 302


def test_manifest_instalable(cliente):
    r = cliente.get("/manifest.json")
    assert r.status_code == 200
    assert r.headers["Content-Type"].startswith("application/manifest+json")
    m = json.loads(r.data)
    for campo in ("name", "short_name", "start_url", "display", "icons", "theme_color", "background_color"):
        assert m.get(campo), campo
    assert m["display"] == "standalone"
    tamanos = {i["sizes"] for i in m["icons"]}
    assert {"192x192", "512x512"} <= tamanos
    for icono in m["icons"]:
        assert cliente.get(icono["src"]).status_code == 200
    assert cliente.get(m["start_url"].split("?")[0]).status_code == 200


def test_service_worker_en_la_raiz(cliente):
    r = cliente.get("/sw.js")
    assert r.status_code == 200
    assert "javascript" in r.headers["Content-Type"]
    assert r.headers["Service-Worker-Allowed"] == "/"
    codigo = r.data.decode()
    for evento in ("'install'", "'activate'", "'fetch'", "'push'", "'notificationclick'"):
        assert evento in codigo


def test_app_shell_existe(cliente):
    """Todo lo que el Service Worker precarga debe responder 200,
    porque si uno falla cache.addAll() cancela la instalación completa."""
    codigo = cliente.get("/sw.js").data.decode()
    bloque = codigo.split("const APP_SHELL = [")[1].split("];")[0]
    rutas = [l.strip().strip(",").strip("'") for l in bloque.splitlines() if "'/" in l]
    assert len(rutas) >= 8
    for ruta in rutas:
        assert cliente.get(ruta).status_code == 200, ruta


def test_resumen_requiere_sesion(cliente):
    assert cliente.get("/api/pwa/resumen").status_code == 401


def test_resumen_con_sesion(sesion):
    d = sesion.get("/api/pwa/resumen").get_json()
    assert d["total"] > 0 and "en_riesgo" in d and "segmentos" in d


def test_vistas_ssr_y_csr(sesion):
    assert sesion.get("/dashboard").status_code == 200          # SSR
    assert sesion.get("/dashboard-csr").status_code == 200      # CSR (esqueleto)
    datos = sesion.get("/api/dashboard-data").get_json()        # CSR (JSON)
    assert "stats" in datos and "campanas" in datos
    assert sesion.get("/comparativa-ssr-csr").status_code == 200


def test_push_clave_vapid(sesion):
    clave = sesion.get("/api/push/clave").get_json()["publicKey"]
    assert len(clave) >= 80


def test_push_suscripcion_invalida(sesion):
    assert sesion.post("/api/push/suscribir", json={}).status_code == 400
