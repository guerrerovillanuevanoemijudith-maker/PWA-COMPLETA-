#!/bin/bash

# ============================================================================
# BancoFinancesChat - Script de Ejecución Rápida (Linux/Mac)
# ============================================================================

clear

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║      🏦 BANCOFINANCESCHAT - Sistema de IA Financiero          ║"
echo "║          Iniciando aplicación en http://localhost:5000        ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

cd "$(dirname "$0")"
cd app

echo "⏳ Verificando dependencias..."

python3 -m pip install --break-system-packages -q -r requirements.txt 2>/dev/null

if [ $? -ne 0 ]; then
    echo "⚠️  Instalando con permisos de usuario..."
    pip install -q --user -r requirements.txt 2>/dev/null
fi

echo "✅ Dependencias OK"
echo ""
echo "🚀 Iniciando aplicación Flask..."
echo ""

python3 app.py

if [ $? -ne 0 ]; then
    echo ""
    echo "❌ Error al iniciar la aplicación"
    exit 1
fi
