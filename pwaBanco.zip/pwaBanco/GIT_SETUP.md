# 🚀 BancoMéxico Finance - Git Local

Tu repositorio Git ya está configurado y listo para usar.

## 📋 ¿Qué se configuró?

✅ **Repositorio Git inicializado** en la carpeta del proyecto
✅ **Pre-commit hook** - Muestra qué archivos se van a commitear antes de ejecutar
✅ **Post-commit hook** - Muestra confirmación exitosa con detalles del commit
✅ **Script auxiliar** - `commit.sh` para commits interactivos con visualización completa
✅ **Usuario Git configurado** - Noemi Judith / noemi.judith@bancoiachat.com

---

## 🎯 Cómo usar

### Opción 1: Commits desde la terminal (CON visualización)

```bash
# Dentro de la carpeta del proyecto, usa el script:
./commit.sh "Tu mensaje de commit aquí"
```

**Esto muestra:**
- ✓ Estado actual del repo
- 📁 Archivos que serán commiteados
- 📊 Estadísticas (archivos nuevos, modificados, eliminados)
- 📈 Líneas añadidas/eliminadas
- Confirmación antes de hacer el commit

### Opción 2: Commits desde VS Code (CON hooks automáticos)

1. Abre la carpeta en VS Code
2. Haz cambios en los archivos
3. Ve a **Source Control** (Ctrl+Shift+G)
4. Escribe tu mensaje en el campo "Message"
5. Haz clic en ✓ (commit) o presiona Ctrl+Enter

**Los hooks se ejecutarán automáticamente:**
- **Pre-commit**: Verifica y muestra qué se va a commitear
- **Post-commit**: Muestra confirmación con detalles

---

## 📝 Ejemplos de commits

```bash
# Usando el script
./commit.sh "Agregar función de autenticación"

# O con git directo
git add .
git commit -m "Agregar función de autenticación"
```

---

## 🔍 Ver historial

```bash
# Ver todos los commits
git log

# Ver commits de forma gráfica
git log --graph --oneline --all

# Ver cambios del último commit
git show

# Ver estado actual
git status
```

---

## 📊 Información del repositorio

- **Rama actual**: master
- **Commits**: Puedes verlos con `git log`
- **Configuración local**: 
  - Usuario: Noemi Judith
  - Email: noemi.judith@bancoiachat.com

---

## ⚠️ Notas importantes

- El directorio `.git/` contiene toda la información del repositorio
- No borres la carpeta `.git/` ni los scripts en `.git/hooks/`
- Los hooks solo funcionan desde terminal/VS Code
- Puedes editar los hooks en `.git/hooks/pre-commit` y `.git/hooks/post-commit` si quieres cambiar lo que se muestra

---

## 🛠️ Cambiar configuración de Git

```bash
# Cambiar nombre de usuario
git config user.name "Tu Nombre"

# Cambiar email
git config user.email "tu@email.com"

# Ver configuración actual
git config --list
```

---

**¡Todo listo! 🎉 Ahora puedes trabajar con Git y ver exactamente qué está sucediendo en cada commit.**
