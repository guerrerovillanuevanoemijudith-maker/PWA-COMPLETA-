# Security utilities for Noemi Judith
import hashlib, secrets

def generate_token(length=32):
    return secrets.token_hex(length)

def hash_password(password):
    salt = secrets.token_hex(16)
    return hashlib.sha256((password + salt).encode()).hexdigest()
