# BancoMéxico Finance – Sistema de Segmentación de Clientes Financieros

> Proyecto estudiantil – Sistema de microsegmentación en tiempo real con IA integrada

---

## 🚀 Instalación y ejecución rápida

### Requisitos previos
- Python 3.9+
- Visual Studio Code
- Git

### Pasos

1. **Crear entorno virtual**
```bash
python -m venv venv
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate
```

2. **Instalar dependencias**
```bash
pip install -r requirements.txt
```

3. **Configurar variables de entorno** (opcional)
```bash
# Si quieres integrar IA, crea un archivo .env con:
# OPENAI_API_KEY=tu_clave_aqui
```

4. **Ejecutar la aplicación**
```bash
python app.py
```

Accede en tu navegador: **http://localhost:5000**

---

## 🔑 Credenciales de acceso (demostración)

| Usuario | Contraseña | Rol |
|---------|-----------|-----|
| admin@banconexus.mx | nexus2024 | Administrador |
| ana@banconexus.mx | analista123 | Analista |

---

## 📁 Estructura del proyecto

```
bancomexicofinance/
├── app.py                  # Aplicación principal (Flask + lógica de negocio)
├── requirements.txt        # Dependencias Python
├── README.md               # Este archivo
├── .gitignore              # Archivos ignorados por Git
├── instance/
│   └── bancofinanciero.db  # Base de datos SQLite (incluida)
├── static/
│   ├── css/main.css        # Estilos CSS
│   └── js/main.js          # Scripts JavaScript (chat, interacciones)
└── templates/
    ├── base.html           # Layout principal
    ├── login.html          # Inicio de sesión
    ├── dashboard.html      # Panel ejecutivo
    ├── clientes.html       # Gestión de clientes
    ├── form_cliente.html   # Formulario de clientes
    ├── detalle_cliente.html# Detalle del cliente
    ├── segmentacion.html   # Análisis de microsegmentación
    ├── campanas.html       # Campañas de marketing
    └── nueva_campana.html  # Crear campaña
```

---

## ⚙️ Funcionalidades principales

### 🏦 Módulos del sistema
- **Autenticación segura** con hash de contraseñas
- **Dashboard ejecutivo** con KPIs en tiempo real
- **Gestión de clientes** – CRUD completo con paginación y filtros
- **Microsegmentación automática** – Algoritmo RFM + crediticio
- **Campañas de marketing** – Creación con ROI estimado
- **Chatbot IA** – Integración con servicios de IA

### 🎯 Segmentación automática
| Segmento | Criterio | Conversión estimada |
|----------|---------|-------------------|
| Premium | Ingreso ≥ $80K + Score ≥ 70 | 18% |
| Alto Valor | Score 55–69 | 12% |
| Medio | Score 35–54 | 7% |
| Básico | Score 20–34 | 5% |
| En Riesgo | Score < 20 | 3–15% |

---

## 🗄️ Base de datos

La aplicación usa **SQLite**. La base de datos se incluye en `instance/bancofinanciero.db` con datos iniciales.

### Tablas principales
- `usuarios` – Acceso y autenticación
- `clientes` – Datos financieros y segmentación
- `campanas` – Campañas con métricas

---

## 📦 Configuración en VS Code

1. Instala la extensión **Python** (Microsoft)
2. Selecciona el intérprete del venv: `Ctrl+Shift+P` → "Python: Select Interpreter" → `./venv/bin/python`
3. Ejecuta en terminal: `python app.py`

---

## 🤖 Integración con IA (opcional)

Para usar el chatbot IA, crea un archivo `.env` en la raíz del proyecto:

```
OPENAI_API_KEY=sk-tu-clave-aqui
```

Sin esta variable, el chatbot funciona con respuestas predefinidas.

---

## 📤 Control de versiones (Git)

```bash
git init
git add .
git commit -m "feat: BancoMéxico Finance - Sistema de segmentación"
git remote add origin https://github.com/tu-usuario/bancomexicofinance.git
git push -u origin master
```

---

*Sistema de microsegmentación de clientes – Python/Flask + SQLite + IA integrada*
