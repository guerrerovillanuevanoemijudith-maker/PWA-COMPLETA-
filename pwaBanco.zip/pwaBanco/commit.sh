#!/bin/bash

# Script auxiliar para hacer commits con visualización completa
# v1.0 - Listo para producción (Commit 40)
# Uso: ./commit.sh "mensaje del commit"

if [ -z "$1" ]; then
    echo "❌ Error: Debes proporcionar un mensaje de commit"
    echo "Uso: ./commit.sh \"tu mensaje aquí\""
    exit 1
fi

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║           🚀 INICIANDO PROCESO DE COMMIT GIT 🚀            ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Mostrar historial de commits recientes
echo "📜 HISTORIAL DE COMMITS RECIENTES:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
git log --oneline --decorate -15 2>/dev/null | while IFS= read -r line; do
    echo "  $line"
done
echo ""

# Mostrar estado actual
echo "📌 ESTADO ACTUAL DEL REPOSITORIO:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
git status -s
echo ""

# Contar cambios sin staged
UNSTAGED=$(git diff --name-only | wc -l)
STAGED=$(git diff --cached --name-only | wc -l)
UNTRACKED=$(git ls-files --others --exclude-standard | wc -l)
TOTAL_COMMITS=$(git rev-list --count HEAD 2>/dev/null || echo "0")

echo "📊 RESUMEN:"
echo "  ├─ Total de commits: $TOTAL_COMMITS"
echo "  ├─ Archivos sin stage: $UNSTAGED"
echo "  ├─ Archivos sin rastrear: $UNTRACKED"
echo "  └─ Archivos en stage: $STAGED"
echo ""

# Preguntar si agregar todos los archivos
if [ "$STAGED" -eq 0 ] && [ "$UNSTAGED" -gt 0 ]; then
    echo "⚠️  No hay archivos en stage. ¿Deseas agregar todos? (s/n)"
    read -r response
    if [[ "$response" == "s" || "$response" == "S" ]]; then
        echo "➕ Agregando todos los archivos..."
        git add -A
        echo "✅ Archivos agregados"
        echo ""
    fi
fi

# Mostrar archivos que se van a commitear
echo "📁 ARCHIVOS A COMMITEAR:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
git diff --cached --name-status | awk '{if($1=="A")print "  ✨ [NUEVO]    "$2; else if($1=="M")print "  📝 [MODIF]    "$2; else if($1=="D")print "  🗑️  [ELIM]     "$2}'
echo ""

# Mostrar diff summary
echo "📈 CAMBIOS RESUMIDOS:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
git diff --cached --stat | tail -1
echo ""

# Mostrar mensaje del commit
echo "💬 MENSAJE DEL COMMIT:"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  $1"
echo ""

# Confirmar antes de commitear
echo "¿Deseas continuar con el commit? (s/n)"
read -r confirm
if [[ "$confirm" != "s" && "$confirm" != "S" ]]; then
    echo "❌ Commit cancelado"
    exit 1
fi

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║              🔄 EJECUTANDO COMMIT...                       ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Ejecutar commit (los hooks se ejecutarán automáticamente)
git commit -m "$1"

NEW_HASH=$(git rev-parse --short HEAD)
NEW_TOTAL=$(git rev-list --count HEAD)

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║              ✅ PROCESO COMPLETADO                         ║"
echo "╠════════════════════════════════════════════════════════════╣"
echo "║  🔖 Hash: $NEW_HASH                                        ║"
echo "║  📦 Total commits: $NEW_TOTAL                              ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Mostrar log actualizado
echo "📜 HISTORIAL ACTUALIZADO (últimos 5):"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
git log --oneline -5 | while IFS= read -r line; do
    echo "  $line"
done
echo ""
