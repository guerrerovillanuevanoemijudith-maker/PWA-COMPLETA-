# ═══════════════════════════════════════════════════════════════════════════════
# pwa_completa.py - Integración final de la PWA (actividad "PWA completa publicada")
# Autora: Noemi Judith Guerrero Villanueva · Matrícula 202204010
# Materia: Desarrollo de Dispositivos Inteligentes
#
# Este módulo NO cambia lo que ya hice en las actividades anteriores. Solo agrega
# lo que faltaba para dejar todo en una sola PWA publicable:
#   - /splash            pantalla de bienvenida (splash)
#   - /inicio            pantalla home pública (se guarda en caché, funciona offline)
#   - /health            chequeo de salud para el hosting y Docker
#   - /api/pwa/resumen   módulo de datos: KPIs en JSON (los guarda IndexedDB en el cliente)
#   - Arranque listo para producción (gunicorn): crea la BD, los datos de ejemplo
#     y las llaves VAPID si todavía no existen.
# ═══════════════════════════════════════════════════════════════════════════════
import base64
import os
from flask import Blueprint, render_template, jsonify, session, request
from werkzeug.middleware.proxy_fix import ProxyFix

pwa = Blueprint("pwa", __name__)


def _generar_vapid_si_falta(base_dir):
    """Crea instance/vapid_private.pem y vapid_public.txt si no existen
    (en el hosting la carpeta instance/ no viaja en el repositorio)."""
    carpeta = os.path.join(base_dir, "instance")
    privada = os.path.join(carpeta, "vapid_private.pem")
    publica = os.path.join(carpeta, "vapid_public.txt")
    if os.path.exists(privada) and os.path.exists(publica):
        return
    try:
        from py_vapid import Vapid
        from cryptography.hazmat.primitives import serialization
        os.makedirs(carpeta, exist_ok=True)
        v = Vapid()
        v.generate_keys()
        v.save_key(privada)
        punto = v.public_key.public_bytes(
            serialization.Encoding.X962,
            serialization.PublicFormat.UncompressedPoint,
        )
        with open(publica, "w", encoding="utf-8") as f:
            f.write(base64.urlsafe_b64encode(punto).decode().rstrip("="))
        print("[PWA] Llaves VAPID generadas")
    except Exception as e:                      # la app sigue sin push si falla
        print("[PWA] No se pudieron generar las llaves VAPID:", e)


def registrar_pwa_completa(app, db, get_stats, seed_data):
    base_dir = os.path.abspath(os.path.dirname(__file__))

    # Detrás del proxy del hosting (HTTPS) Flask debe respetar X-Forwarded-*
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
    app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
    app.config["SESSION_COOKIE_HTTPONLY"] = True
    if os.environ.get("PWA_HTTPS") == "1":
        app.config["SESSION_COOKIE_SECURE"] = True

    @app.after_request
    def cabeceras_seguridad(resp):
        if request.is_secure:
            resp.headers.setdefault("Strict-Transport-Security", "max-age=31536000")
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        return resp

    # Con "python app.py" esto ya lo hace el bloque __main__, pero con gunicorn no.
    os.makedirs(os.path.join(base_dir, "instance"), exist_ok=True)
    with app.app_context():
        db.create_all()
        seed_data()
    _generar_vapid_si_falta(base_dir)

    @pwa.route("/splash")
    def splash():
        return render_template("splash.html")

    @pwa.route("/inicio")
    def inicio():
        return render_template("home.html", logueado="user_id" in session,
                               nombre=session.get("user_nombre", ""))

    @pwa.route("/health")
    def health():
        return jsonify({"status": "ok", "app": "FinancePWA"})

    @pwa.route("/api/pwa/resumen")
    def api_resumen():
        # Si no hay sesión se responde 401 en JSON (no un redirect a /login)
        # para que el módulo de datos del navegador sepa qué hacer.
        if "user_id" not in session:
            return jsonify({"error": "no_autenticado"}), 401
        stats = get_stats()
        return jsonify({
            "total": stats["total"],
            "en_riesgo": stats["en_riesgo"],
            "ingreso_promedio": stats["ingreso_promedio"],
            "segmentos": stats["por_segmento"],
        })

    # El blueprint se registra al final, cuando ya tiene todas sus rutas
    app.register_blueprint(pwa)
