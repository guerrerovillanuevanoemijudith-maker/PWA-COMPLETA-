/* ===========================================================
   Service Worker - BancoFinancesIA PWA
   Autor: Noemi Judith Guerrero Villanueva
   Materia: Desarrollo de Dispositivos Inteligentes
   Descripción: Script que se ejecuta en segundo plano del
   navegador (fuera del hilo principal de la página) y que
   permite el funcionamiento offline, la gestión de la caché
   y la optimización del rendimiento de la aplicación.
   =========================================================== */

// Nombre y versión de la caché. Cambiar el número de versión
// obliga a los navegadores a regenerar la caché (invalidación).
const CACHE_VERSION = 'v2';
const CACHE_STATIC = `financepwa-static-${CACHE_VERSION}`;
const CACHE_DYNAMIC = `financepwa-dynamic-${CACHE_VERSION}`;

// Recursos "shell" de la aplicación que se guardan en caché
// desde el primer momento (App Shell Pattern).
const APP_SHELL = [
  '/inicio',
  '/splash',
  '/login',
  '/static/css/main.css',
  '/static/css/pwa-completa.css',
  '/static/js/main.js',
  '/static/js/pwa-completa.js',
  '/static/js/modulo-datos.js',
  '/static/manifest.json',
  '/static/icons/icon-192.png',
  '/static/icons/icon-512.png',
  '/offline'
];

/* -----------------------------------------------------------
   EVENTO: install
   Se dispara cuando el Service Worker se instala por primera
   vez. Aquí se abre la caché estática y se precargan los
   recursos del App Shell para que la app arranque sin red.
   ----------------------------------------------------------- */
self.addEventListener('install', (event) => {
  console.log('[Service Worker] Instalando...');
  event.waitUntil(
    caches.open(CACHE_STATIC)
      .then((cache) => {
        console.log('[Service Worker] Cacheando App Shell');
        return cache.addAll(APP_SHELL);
      })
      .then(() => self.skipWaiting()) // activa el nuevo SW de inmediato
  );
});

/* -----------------------------------------------------------
   EVENTO: activate
   Se dispara cuando el Service Worker toma el control. Aquí
   se limpian cachés antiguas (de versiones anteriores) para
   optimizar el espacio y evitar servir contenido obsoleto.
   ----------------------------------------------------------- */
self.addEventListener('activate', (event) => {
  console.log('[Service Worker] Activando...');
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys
          .filter((key) => key !== CACHE_STATIC && key !== CACHE_DYNAMIC)
          .map((key) => {
            console.log('[Service Worker] Eliminando caché antigua:', key);
            return caches.delete(key);
          })
      );
    }).then(() => self.clients.claim()) // controla las páginas ya abiertas
  );
});

/* -----------------------------------------------------------
   EVENTO: fetch
   Intercepta cada petición de red de la aplicación y decide
   la estrategia de caché según el tipo de recurso:
   - API (/api/...)      -> Network First (datos siempre frescos,
                             con respaldo en caché si falla la red)
   - Estáticos (css/js/img) -> Cache First (rendimiento óptimo)
   - Navegación (páginas)   -> Network First con fallback a /offline
   ----------------------------------------------------------- */
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Solo gestionamos peticiones GET del mismo origen
  if (request.method !== 'GET' || url.origin !== self.location.origin) {
    return;
  }

  // 1) Peticiones a la API -> Network First
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(networkFirst(request));
    return;
  }

  // 2) Navegación entre páginas -> Network First + fallback offline
  if (request.mode === 'navigate') {
    event.respondWith(navegacion(request));
    return;
  }

  // 3) Recursos estáticos (css, js, imágenes, fuentes) -> Cache First
  if (
    request.destination === 'style' ||
    request.destination === 'script' ||
    request.destination === 'image' ||
    request.destination === 'font'
  ) {
    event.respondWith(cacheFirst(request));
    return;
  }

  // 4) Cualquier otro caso -> intenta red y cae a caché
  event.respondWith(networkFirst(request));
});

/* -----------------------------------------------------------
   ESTRATEGIA: Cache First
   Ideal para recursos estáticos que casi nunca cambian.
   Mejora el rendimiento porque evita ir a la red cuando el
   recurso ya está disponible localmente.
   ----------------------------------------------------------- */
async function cacheFirst(request) {
  const cached = await caches.match(request);
  if (cached) return cached;

  try {
    const response = await fetch(request);
    const cache = await caches.open(CACHE_STATIC);
    cache.put(request, response.clone());
    return response;
  } catch (err) {
    console.warn('[Service Worker] Recurso no disponible offline:', request.url);
    return new Response('Recurso no disponible sin conexión', { status: 504 });
  }
}

/* -----------------------------------------------------------
   ESTRATEGIA: Network First
   Ideal para datos dinámicos (API, páginas). Intenta obtener
   la versión más reciente de la red y, si falla (sin
   conexión), recurre a la caché dinámica como respaldo.
   ----------------------------------------------------------- */
async function networkFirst(request) {
  try {
    const response = await fetch(request);
    // Solo se guardan respuestas correctas y sin redirección (una respuesta
    // redirigida no puede usarse después para una navegación offline).
    if (response.ok && !response.redirected) {
      const cache = await caches.open(CACHE_DYNAMIC);
      cache.put(request, response.clone());
    }
    return response;
  } catch (err) {
    const cached = await caches.match(request);
    if (cached) return cached;
    throw err;
  }
}

/* -----------------------------------------------------------
   ESTRATEGIA: navegación (páginas completas)
   Red primero; sin conexión usa la página ya visitada. Si no
   existe en caché: la raíz "/" cae a la pantalla de inicio y
   cualquier otra ruta cae a la página /offline.
   ----------------------------------------------------------- */
async function navegacion(request) {
  try {
    return await networkFirst(request);
  } catch (err) {
    const url = new URL(request.url);
    if (url.pathname === '/') {
      const inicio = await caches.match('/inicio');
      if (inicio) return inicio;
    }
    return caches.match('/offline');
  }
}

/* -----------------------------------------------------------
   EVENTO: message
   Permite que la página le indique al Service Worker que
   active la nueva versión inmediatamente (patrón "skip
   waiting" controlado desde el cliente).
   ----------------------------------------------------------- */
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

/* -----------------------------------------------------------
   EVENTO: push  (actividad: notificaciones push)
   El servicio push del navegador despierta al Service Worker
   cuando el servidor manda un mensaje, aunque la PWA esté
   cerrada. Aquí se muestra la notificación en el dispositivo.
   ----------------------------------------------------------- */
self.addEventListener('push', (event) => {
  let datos = { title: 'FinancePWA', body: 'Tienes una notificación nueva', url: '/' };
  if (event.data) {
    try { datos = Object.assign(datos, event.data.json()); }
    catch (e) { datos.body = event.data.text(); }
  }
  event.waitUntil(
    self.registration.showNotification(datos.title, {
      body: datos.body,
      icon: '/static/icons/icon-192.png',
      badge: '/static/icons/icon-192.png',
      tag: 'financepwa-push',
      data: { url: datos.url }
    })
  );
});

/* -----------------------------------------------------------
   EVENTO: notificationclick
   Al tocar la notificación se abre (o enfoca) la PWA en la
   pantalla indicada en el mensaje.
   ----------------------------------------------------------- */
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const destino = (event.notification.data && event.notification.data.url) || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((ventanas) => {
      for (const v of ventanas) {
        if (v.url.includes(destino) && 'focus' in v) return v.focus();
      }
      return clients.openWindow(destino);
    })
  );
});
