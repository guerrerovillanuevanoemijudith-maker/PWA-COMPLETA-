// ─── BancoMexicoFinance Main JS ─────────────────────────────────────────────

// Chat toggle
function toggleChat() {
  const panel = document.getElementById('chatPanel');
  if (panel) panel.classList.toggle('open');
}

// Sugerencias rápidas
const sugerencias = [
  "¿Cuántos clientes están en riesgo?",
  "¿Cuáles son los canales preferidos?",
  "Dame un resumen del sistema",
  "¿Qué segmento tiene más clientes?",
];

function insertarSugerencia(texto) {
  document.getElementById('chatInput').value = texto;
  sendChat();
}

// Enviar mensaje al chat
async function sendChat() {
  const input = document.getElementById('chatInput');
  const messages = document.getElementById('chatMessages');
  const mensaje = input.value.trim();
  if (!mensaje) return;

  // Deshabilitar mientras espera
  input.disabled = true;
  const sendBtn = document.querySelector('.chat-send');
  if (sendBtn) sendBtn.disabled = true;

  // Mensaje del usuario
  messages.innerHTML += `
    <div class="msg-user">
      <div class="msg-bubble">${escapeHtml(mensaje)}</div>
    </div>`;
  input.value = '';
  messages.scrollTop = messages.scrollHeight;

  // Indicador de carga animado
  const loadId = 'load-' + Date.now();
  messages.innerHTML += `
    <div class="msg-bot msg-loading" id="${loadId}">
      <div class="msg-bubble typing-indicator"><span></span><span></span><span></span></div>
    </div>`;
  messages.scrollTop = messages.scrollHeight;

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mensaje })
    });

    if (!res.ok) throw new Error('HTTP ' + res.status);

    const data = await res.json();
    const loadEl = document.getElementById(loadId);
    if (loadEl) loadEl.remove();

    const html = formatResponse(data.respuesta || 'Sin respuesta.');
    messages.innerHTML += `
      <div class="msg-bot">
        <div class="msg-bubble">${html}</div>
      </div>`;
  } catch (e) {
    const loadEl = document.getElementById(loadId);
    if (loadEl) loadEl.remove();
    messages.innerHTML += `
      <div class="msg-bot">
        <div class="msg-bubble">⚠️ Error de conexión. Intenta de nuevo.</div>
      </div>`;
  }

  input.disabled = false;
  if (sendBtn) sendBtn.disabled = false;
  input.focus();
  messages.scrollTop = messages.scrollHeight;
}

// Formatear respuesta con markdown básico
function formatResponse(text) {
  return text
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n/g, '<br>');
}

function escapeHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// Enter para enviar
document.addEventListener('DOMContentLoaded', () => {
  // Flash messages auto-dismiss
  document.querySelectorAll('.flash').forEach(el => {
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transition = 'opacity .5s';
      setTimeout(() => el.remove(), 500);
    }, 4000);
  });

  // Soporte Enter en el input del chat
  const chatInput = document.getElementById('chatInput');
  if (chatInput) {
    chatInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendChat();
      }
    });
  }
});

// Navegar a sección desde el chat
function abrirSeccion(seccion) {
  const rutas = {
    'segmentacion': '/segmentacion',
    'campanas': '/campanas'
  };
  const mensajes = {
    'segmentacion': 'Abriendo Segmentación...',
    'campanas': 'Abriendo Campañas...'
  };
  const messages = document.getElementById('chatMessages');
  if (mensajes[seccion]) {
    messages.innerHTML += `
      <div class="msg-user">
        <div class="msg-bubble">${escapeHtml(mensajes[seccion])}</div>
      </div>`;
    messages.scrollTop = messages.scrollHeight;
  }
  setTimeout(() => {
    if (rutas[seccion]) window.location.href = rutas[seccion];
  }, 400);
}

// Reset chat
function resetChat() {
  const messages = document.getElementById('chatMessages');
  messages.innerHTML = `
    <div class="msg-bot">
      <div class="msg-bubble">¡Hola! Soy <strong>FinancuerAI</strong> de BancoMexicoFinance. Analizo datos reales del sistema para ayudarte. ¿Qué necesitas?</div>
    </div>
    <div class="chat-suggestions">
      <button class="chat-chip" onclick="insertarSugerencia('¿Cuántos clientes están en riesgo de abandono?')">🔴 Clientes en riesgo</button>
      <button class="chat-chip" onclick="insertarSugerencia('¿Cuáles son los canales de comunicación preferidos?')">📊 Ver canales</button>
      <button class="chat-chip" onclick="insertarSugerencia('Dame un resumen del sistema financiero')">📋 Resumen</button>
      <button class="chat-chip" onclick="insertarSugerencia('¿Qué segmento tiene más clientes?')">🏆 Top segmento</button>
      <button class="chat-chip" onclick="abrirSeccion('segmentacion')">🌐 Segmentación</button>
      <button class="chat-chip" onclick="abrirSeccion('campanas')">✉️ Campañas</button>
    </div>`;
}
