/* ===========================================================
   modulo-datos.js - Módulo de datos de la PWA
   Autora: Noemi Judith Guerrero Villanueva · Matrícula 202204010

   Guarda en IndexedDB (base "financepwa-db") el último resumen
   de datos que llegó del servidor. Así, si el usuario abre la
   app sin internet, todavía ve los números de la última vez.
   Estrategia: red primero y, si falla, lo guardado en el dispositivo.
   =========================================================== */
(function (global) {
  'use strict';
  var DB = 'financepwa-db', STORE = 'datos';

  function abrir() {
    return new Promise(function (ok, fallo) {
      if (!global.indexedDB) return fallo(new Error('IndexedDB no disponible'));
      var rq = indexedDB.open(DB, 1);
      rq.onupgradeneeded = function () { rq.result.createObjectStore(STORE); };
      rq.onsuccess = function () { ok(rq.result); };
      rq.onerror = function () { fallo(rq.error); };
    });
  }
  function guardar(clave, valor) {
    return abrir().then(function (db) {
      return new Promise(function (ok, fallo) {
        var tx = db.transaction(STORE, 'readwrite');
        tx.objectStore(STORE).put({ valor: valor, guardado: Date.now() }, clave);
        tx.oncomplete = function () { ok(); };
        tx.onerror = function () { fallo(tx.error); };
      });
    });
  }
  function leer(clave) {
    return abrir().then(function (db) {
      return new Promise(function (ok, fallo) {
        var rq = db.transaction(STORE).objectStore(STORE).get(clave);
        rq.onsuccess = function () { ok(rq.result || null); };
        rq.onerror = function () { fallo(rq.error); };
      });
    });
  }
  // Devuelve { datos, origen: 'red' | 'dispositivo', guardado } o null si no hay nada.
  function obtenerResumen() {
    // Sin conexión: se usa directamente lo guardado en el dispositivo
    // (así no se confunde con la copia que el Service Worker tiene en caché).
    if (navigator.onLine === false) {
      return leer('resumen').then(function (reg) {
        return reg ? { datos: reg.valor, origen: 'dispositivo', guardado: reg.guardado } : null;
      }).catch(function () { return null; });
    }
    return fetch('/api/pwa/resumen', { credentials: 'same-origin' })
      .then(function (r) {
        if (r.status === 401) return null;
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json().then(function (datos) {
          return guardar('resumen', datos).catch(function () {}).then(function () {
            return { datos: datos, origen: 'red', guardado: Date.now() };
          });
        });
      })
      .catch(function () {
        return leer('resumen').then(function (reg) {
          return reg ? { datos: reg.valor, origen: 'dispositivo', guardado: reg.guardado } : null;
        }).catch(function () { return null; });
      });
  }
  global.DatosPWA = { guardar: guardar, leer: leer, obtenerResumen: obtenerResumen };
})(window);
