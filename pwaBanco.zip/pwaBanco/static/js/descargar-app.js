/* ===========================================================
   descargar-app.js - Opción "Descargar aplicación"
   Autora: Noemi Judith Guerrero Villanueva · Matrícula 202204010
   Materia: Desarrollo de Dispositivos Inteligentes

   Agrega una opción visible para descargar (instalar) la PWA en el
   dispositivo. No cambia nada de lo anterior; solo se suma:
   - Si el navegador permite instalar (beforeinstallprompt), el botón
     abre el cuadro de instalación del sistema.
   - Si no lo permite (iPhone/iPad con Safari, Firefox, etc.), muestra
     una ventana con los pasos manuales para instalarla.
   - Si la app ya está instalada, lo indica y oculta el botón.
   El botón aparece en: pantalla de inicio, menú lateral y, en las
   pantallas sin menú (como el login), como botón flotante.
   =========================================================== */
(function () {
  'use strict';
  if (window.__descargarAppListo) return;
  window.__descargarAppListo = true;

  var promptDescarga = null;
  var botones = [];

  /* ---------- Estilos (se inyectan para no tocar los CSS existentes) ---------- */
  var css = [
    '.btn-descargar{display:inline-flex;align-items:center;gap:8px;border:0;cursor:pointer;text-decoration:none;',
    'background:#00b4d8;color:#0f3460;font-weight:700;padding:10px 18px;border-radius:8px;font-size:.95rem;font-family:inherit}',
    '.btn-descargar svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}',
    '.btn-descargar[hidden]{display:none}',
    '.btn-descargar-flotante{position:fixed;left:16px;bottom:16px;z-index:9997;box-shadow:0 4px 16px rgba(0,0,0,.25)}',
    '.nav-item.nav-descargar{cursor:pointer;background:none;border:0;width:100%;text-align:left;font:inherit;color:inherit}',
    '.dl-fondo{position:fixed;inset:0;background:rgba(10,20,40,.6);z-index:10000;display:flex;align-items:center;justify-content:center;padding:16px}',
    '.dl-fondo[hidden]{display:none}',
    '.dl-caja{background:#fff;color:#1a202c;max-width:420px;width:100%;border-radius:14px;padding:22px;',
    'font-family:"Plus Jakarta Sans",system-ui,sans-serif;box-shadow:0 12px 40px rgba(0,0,0,.35)}',
    '.dl-caja h3{margin:0 0 6px;font-size:1.15rem;color:#0f3460}',
    '.dl-caja p{margin:0 0 10px;color:#4a5568;font-size:.92rem}',
    '.dl-caja ol{margin:0 0 14px;padding-left:20px;font-size:.92rem;line-height:1.6}',
    '.dl-caja .dl-cerrar{border:0;cursor:pointer;background:#0f3460;color:#fff;font-weight:600;padding:9px 18px;border-radius:8px;font-family:inherit}',
    '.dl-estado{display:inline-block;background:#e6fffa;color:#276749;font-weight:600;padding:8px 14px;border-radius:8px;font-size:.9rem}'
  ].join('');
  var st = document.createElement('style');
  st.id = 'estilosDescargarApp';
  st.textContent = css;
  document.head.appendChild(st);

  var ICONO = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>' +
              '<polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>';

  /* ---------- Detección de entorno ---------- */
  function instalada() {
    return (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) ||
           window.navigator.standalone === true;
  }
  function esIOS() {
    return /iphone|ipad|ipod/i.test(navigator.userAgent) ||
           (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  }

  /* ---------- Ventana con instrucciones ---------- */
  var fondo = null;
  function ventana() {
    if (fondo) return fondo;
    fondo = document.createElement('div');
    fondo.className = 'dl-fondo';
    fondo.hidden = true;
    fondo.setAttribute('role', 'dialog');
    fondo.setAttribute('aria-modal', 'true');
    fondo.innerHTML = '<div class="dl-caja"><div id="dlContenido"></div>' +
                      '<button type="button" class="dl-cerrar" id="dlCerrar">Entendido</button></div>';
    document.body.appendChild(fondo);
    fondo.addEventListener('click', function (e) { if (e.target === fondo) fondo.hidden = true; });
    fondo.querySelector('#dlCerrar').addEventListener('click', function () { fondo.hidden = true; });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') fondo.hidden = true; });
    return fondo;
  }
  function mostrarInstrucciones() {
    var v = ventana(), h;
    if (instalada()) {
      h = '<h3>Aplicación instalada</h3><p>Ya estás usando Financueraba como aplicación en este dispositivo.</p>' +
          '<span class="dl-estado">✔ Instalada</span><br><br>';
    } else if (esIOS()) {
      h = '<h3>Descargar la aplicación</h3><p>En iPhone o iPad se instala desde Safari:</p><ol>' +
          '<li>Toca el botón <b>Compartir</b> (el cuadro con la flecha hacia arriba).</li>' +
          '<li>Elige <b>Añadir a pantalla de inicio</b>.</li>' +
          '<li>Toca <b>Añadir</b>. El ícono de FinancePWA aparecerá con tus apps.</li></ol>';
    } else {
      h = '<h3>Descargar la aplicación</h3><p>Tu navegador no mostró el cuadro automático. Instálala manualmente:</p><ol>' +
          '<li>Abre el menú del navegador (⋮ o ⋯).</li>' +
          '<li>Elige <b>Instalar aplicación</b> o <b>Añadir a pantalla de inicio</b>.</li>' +
          '<li>En computadora, también puedes usar el ícono de instalar que aparece en la barra de direcciones.</li></ol>' +
          '<p>Si no ves la opción, abre la página con <b>Chrome</b> o <b>Edge</b> y por una dirección HTTPS.</p>';
    }
    v.querySelector('#dlContenido').innerHTML = h;
    v.hidden = false;
  }

  /* ---------- Acción del botón ---------- */
  function descargar() {
    if (instalada()) { mostrarInstrucciones(); return; }
    if (promptDescarga) {
      var p = promptDescarga;
      promptDescarga = null;                       // el evento solo se puede usar una vez
      try {
        p.prompt();
        p.userChoice.then(function (r) {
          if (r && r.outcome === 'accepted') ocultarTodos();
        });
      } catch (e) { mostrarInstrucciones(); }      // otro botón ya lo usó: mostramos los pasos
    } else {
      mostrarInstrucciones();
    }
  }

  function ocultarTodos() {
    botones.forEach(function (b) { b.hidden = true; });
    var otro = document.getElementById('btnInstalar');
    if (otro) otro.hidden = true;
  }

  /* ---------- Crear los botones ---------- */
  function crearBoton(clase, etiqueta) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = clase;
    b.innerHTML = ICONO + '<span>' + etiqueta + '</span>';
    b.addEventListener('click', descargar);
    botones.push(b);
    return b;
  }

  function montar() {
    if (instalada()) return;                       // ya instalada: no se muestra
    if (location.pathname === '/splash') return;   // el splash dura un instante
    var colocado = false;

    var acciones = document.querySelector('.hero-acciones');
    if (acciones) {
      acciones.appendChild(crearBoton('btn-descargar', 'Descargar aplicación'));
      colocado = true;
    }

    var nav = document.querySelector('.sidebar-nav');
    if (nav) {
      var item = document.createElement('button');
      item.type = 'button';
      item.className = 'nav-item nav-descargar';
      item.innerHTML = ICONO + 'Descargar app';
      item.addEventListener('click', descargar);
      botones.push(item);
      nav.appendChild(item);
      colocado = true;
    }

    if (!colocado) {                               // login y demás pantallas sin menú
      document.body.appendChild(crearBoton('btn-descargar btn-descargar-flotante', 'Descargar aplicación'));
    }
  }

  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();                            // evita la mini-barra y guarda el evento
    promptDescarga = e;
  });
  window.addEventListener('appinstalled', function () {
    promptDescarga = null;
    ocultarTodos();
  });

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', montar);
  else montar();
})();
