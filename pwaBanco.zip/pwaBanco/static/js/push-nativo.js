/* ===========================================================
   push-nativo.js - Notificaciones push y características nativas
   Autora: Noemi Judith Guerrero Villanueva · Matrícula 202204010
   Actividad: Notificaciones push y acceso a características

   Qué hace:
     - Paso 2: pide permiso de notificaciones, muestra una
       notificación de prueba, se suscribe a push (pushManager)
       y pide al servidor que envíe un push real.
     - Paso 3: usa la API de Geolocalización (característica
       nativa del dispositivo) respetando el permiso.
     - Paso 4: maneja los tres estados del permiso
       (default / granted / denied) y los errores de cada API.
   =========================================================== */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var escuchandoGeo = false;   // para registrar el onchange del permiso una sola vez

  /* ---------- utilidades ---------- */
  function log(msg) {
    var caja = $('pnLog');
    var hora = new Date().toLocaleTimeString('es-MX');
    caja.textContent += '[' + hora + '] ' + msg + '\n';
    caja.scrollTop = caja.scrollHeight;
  }

  function aviso(id, tipo, texto) {
    var el = $(id);
    el.className = 'pn-aviso ' + tipo;
    el.textContent = texto;
  }

  function chip(id, estado) {
    var el = $(id);
    el.className = 'pn-chip ' + estado;
    el.textContent = estado;
  }

  // La clave VAPID llega en base64 y pushManager la necesita como Uint8Array
  function base64AUint8(base64) {
    var relleno = '='.repeat((4 - base64.length % 4) % 4);
    var b64 = (base64 + relleno).replace(/-/g, '+').replace(/_/g, '/');
    var crudo = atob(b64);
    var salida = new Uint8Array(crudo.length);
    for (var i = 0; i < crudo.length; i++) salida[i] = crudo.charCodeAt(i);
    return salida;
  }

  /* ---------- estado de permisos (paso 4) ---------- */
  function refrescarEstados() {
    if ('Notification' in window) {
      chip('chipNotif', Notification.permission);
    } else {
      chip('chipNotif', 'denied');
      aviso('avisoPush', 'error', 'Este navegador no soporta la API de notificaciones.');
    }
    if (navigator.permissions) {
      navigator.permissions.query({ name: 'geolocation' }).then(function (p) {
        chip('chipGeo', p.state);
        if (!escuchandoGeo) {
          escuchandoGeo = true;
          p.onchange = function () { chip('chipGeo', p.state); log('Permiso de ubicación cambió a: ' + p.state); };
        }
      }).catch(function () { chip('chipGeo', 'prompt'); });
    } else {
      chip('chipGeo', 'prompt');
    }
    if (!('serviceWorker' in navigator)) { $('chipSw').textContent = 'no soportado'; return; }
    navigator.serviceWorker.getRegistration().then(function (reg) {
      $('chipSw').textContent = reg ? 'activo' : 'sin registrar';
      $('chipSw').className = 'pn-chip ' + (reg ? 'granted' : 'denied');
      if (reg && reg.pushManager) {
        reg.pushManager.getSubscription().then(function (s) {
          $('chipSub').textContent = s ? 'suscrita' : 'sin suscripción';
          $('chipSub').className = 'pn-chip ' + (s ? 'granted' : 'prompt');
        });
      }
    });
  }

  /* ---------- PASO 2: solicitar permiso ---------- */
  function pedirPermiso() {
    if (!('Notification' in window)) return Promise.resolve('denied');
    log('Solicitando permiso de notificaciones...');
    return Notification.requestPermission().then(function (res) {
      log('Respuesta del usuario: ' + res);
      refrescarEstados();
      if (res === 'granted') {
        aviso('avisoPush', 'ok', 'Permiso concedido. Ya se pueden mostrar notificaciones.');
      } else if (res === 'denied') {
        aviso('avisoPush', 'error', 'Permiso denegado. La app no puede mostrar notificaciones; el usuario puede reactivarlas desde la configuración del sitio en el navegador.');
      } else {
        aviso('avisoPush', 'info', 'No se eligió ninguna opción (permiso sin decidir).');
      }
      return res;
    });
  }

  /* ---------- PASO 2: notificación de prueba (local) ---------- */
  function notificacionLocal() {
    if (!('Notification' in window)) return aviso('avisoPush', 'error', 'API de notificaciones no disponible.');
    if (Notification.permission === 'denied') {
      log('Intento bloqueado: el permiso está denegado.');
      return aviso('avisoPush', 'error', 'No se puede notificar: el permiso está denegado.');
    }
    var mostrar = function () {
      navigator.serviceWorker.ready.then(function (reg) {
        return reg.showNotification('FinancePWA · Prueba local', {
          body: 'Notificación mostrada por el Service Worker.',
          icon: '/static/icons/icon-192.png',
          tag: 'financepwa-prueba',
          data: { url: '/notificaciones-nativas' }
        });
      }).then(function () {
        log('Notificación local mostrada con registration.showNotification()');
        aviso('avisoPush', 'ok', 'Notificación de prueba enviada al dispositivo.');
      });
    };
    if (Notification.permission === 'granted') mostrar();
    else pedirPermiso().then(function (r) { if (r === 'granted') mostrar(); });
  }

  /* ---------- PASO 1/2: suscripción push ---------- */
  function suscribir() {
    if (!('PushManager' in window)) return aviso('avisoPush', 'error', 'Este navegador no soporta Push API.');
    var pasos = Notification.permission === 'granted' ? Promise.resolve('granted') : pedirPermiso();
    pasos.then(function (res) {
      if (res !== 'granted') throw new Error('Sin permiso de notificaciones');
      log('1) Pidiendo clave pública VAPID al servidor...');
      return fetch('/api/push/clave').then(function (r) { return r.json(); });
    }).then(function (k) {
      log('2) Clave recibida. Creando suscripción con pushManager.subscribe()...');
      return navigator.serviceWorker.ready.then(function (reg) {
        return reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: base64AUint8(k.publicKey)
        });
      });
    }).then(function (sub) {
      log('3) El navegador devolvió el endpoint: ' + sub.endpoint.slice(0, 60) + '...');
      return fetch('/api/push/suscribir', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sub)
      }).then(function (r) { return r.json(); });
    }).then(function (r) {
      log('4) Servidor guardó la suscripción. Total: ' + r.total);
      aviso('avisoPush', 'ok', 'Suscripción push guardada en el servidor.');
      refrescarEstados();
    }).catch(function (e) {
      log('Error en la suscripción: ' + e.message);
      aviso('avisoPush', 'error', 'No se pudo suscribir: ' + e.message);
    });
  }

  function enviarDesdeServidor() {
    log('Pidiendo al servidor que envíe un push de prueba...');
    fetch('/api/push/enviar-prueba', { method: 'POST' })
      .then(function (r) { return r.json(); })
      .then(function (r) {
        if (!r.ok) throw new Error(r.error || 'error');
        log('Servidor -> enviados: ' + r.enviados + ', fallidos: ' + r.fallidos);
        aviso('avisoPush', r.enviados ? 'ok' : 'info',
          r.enviados ? 'Push enviado por el servidor (' + r.enviados + ').' : 'No hay suscripciones válidas. Primero pulsa "Suscribirme a push".');
      })
      .catch(function (e) { aviso('avisoPush', 'error', 'Error: ' + e.message); });
  }

  /* ---------- verificación: qué notificaciones tiene mostradas el Service Worker ---------- */
  function verActivas() {
    navigator.serviceWorker.ready.then(function (reg) {
      return reg.getNotifications();
    }).then(function (lista) {
      log('Notificaciones mostradas por el Service Worker: ' + lista.length);
      lista.forEach(function (n, i) { log('  ' + (i + 1) + '. ' + n.title + ' - ' + n.body); });
      aviso('avisoPush', 'info', 'Notificaciones activas: ' + lista.length + ' (detalle en la bitácora).');
    });
  }

  /* ---------- PASO 3: característica nativa -> geolocalización ---------- */
  function obtenerUbicacion() {
    if (!('geolocation' in navigator)) {
      return aviso('avisoGeo', 'error', 'Este dispositivo no soporta geolocalización.');
    }
    log('Solicitando ubicación con navigator.geolocation.getCurrentPosition()...');
    aviso('avisoGeo', 'info', 'Solicitando ubicación...');
    navigator.geolocation.getCurrentPosition(function (pos) {
      var c = pos.coords;
      $('geoLat').textContent = c.latitude.toFixed(5);
      $('geoLon').textContent = c.longitude.toFixed(5);
      $('geoPrec').textContent = Math.round(c.accuracy) + ' m';
      $('geoHora').textContent = new Date(pos.timestamp).toLocaleTimeString('es-MX');
      $('geoMapa').href = 'https://www.openstreetmap.org/?mlat=' + c.latitude + '&mlon=' + c.longitude + '#map=16/' + c.latitude + '/' + c.longitude;
      $('geoResultado').style.display = 'grid';
      $('geoMapa').style.display = 'inline-block';
      log('Ubicación obtenida: ' + c.latitude.toFixed(5) + ', ' + c.longitude.toFixed(5));
      aviso('avisoGeo', 'ok', 'Permiso concedido: se obtuvo la ubicación del dispositivo.');
    }, function (err) {
      $('geoResultado').style.display = 'none';
      $('geoMapa').style.display = 'none';
      var mensajes = {
        1: 'Permiso denegado: el usuario no permitió el acceso a la ubicación. La app sigue funcionando sin ella.',
        2: 'Ubicación no disponible (sin GPS o sin señal).',
        3: 'Se agotó el tiempo de espera para obtener la ubicación.'
      };
      log('Error de geolocalización (' + err.code + '): ' + err.message);
      aviso('avisoGeo', 'error', mensajes[err.code] || err.message);
    }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 });
  }

  /* ---------- eventos ---------- */
  document.addEventListener('DOMContentLoaded', function () {
    $('btnPermiso').addEventListener('click', pedirPermiso);
    $('btnLocal').addEventListener('click', notificacionLocal);
    $('btnSuscribir').addEventListener('click', suscribir);
    $('btnServidor').addEventListener('click', enviarDesdeServidor);
    $('btnActivas').addEventListener('click', verActivas);
    $('btnUbicacion').addEventListener('click', obtenerUbicacion);
    $('btnLimpiar').addEventListener('click', function () { $('pnLog').textContent = ''; });
    refrescarEstados();
    // el Service Worker se registra en base.html: se vuelve a leer su estado cuando esté listo
    if ('serviceWorker' in navigator) navigator.serviceWorker.ready.then(refrescarEstados);
    log('Página cargada. Revisa el estado de los permisos.');
  });
})();
