/* ===========================================================
   dashboard-csr.js - Dashboard con Client-Side Rendering (CSR)
   Autora: Noemi Judith Guerrero Villanueva · Matrícula 202204010
   Actividad: Renderizado del lado del servidor (SSR) en una PWA

   La ruta /dashboard-csr entrega un HTML casi vacío (solo el
   contenedor <div id="csr-root">). Este script:
     1) pinta un skeleton (loader vacío)
     2) pide los datos en JSON a /api/dashboard-data
     3) arma en el navegador los mismos KPIs, la misma lista de
        clientes en riesgo y la misma tabla que en la versión SSR
   Cuando termina avisa con el evento "csr:listo" para que
   perf-metrics.js mida el momento en que ya hay contenido útil.
   =========================================================== */
document.addEventListener('DOMContentLoaded', function () {
  renderSkeleton();                                   // 1) loader vacío
  fetch('/api/dashboard-data')                        // 2) se piden los datos
    .then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    })
    .then(function (data) {
      renderDashboard(data);                          // 3) se arma el DOM
      window.dispatchEvent(new Event('csr:listo'));
    })
    .catch(function (err) {
      console.error('[CSR] Error al cargar el dashboard:', err);
      var root = document.getElementById('csr-root');
      if (root) root.innerHTML = '<p class="empty-state">No se pudieron cargar los datos.</p>';
    });
});

function esc(t) {
  var d = document.createElement('div');
  d.textContent = (t === null || t === undefined) ? '' : String(t);
  return d.innerHTML;
}

function pesos(n) {
  return '$' + Math.round(n || 0).toLocaleString('en-US');
}

function renderSkeleton() {
  var root = document.getElementById('csr-root');
  if (!root) return;
  var kpis = '';
  for (var i = 0; i < 4; i++) kpis += '<div class="kpi-card csr-skeleton"></div>';
  root.innerHTML =
    '<div class="kpi-grid">' + kpis + '</div>' +
    '<div class="two-col">' +
      '<div class="card csr-skeleton csr-skeleton-box"></div>' +
      '<div class="card csr-skeleton csr-skeleton-box"></div>' +
    '</div>';
}

function renderDashboard(data) {
  var root = document.getElementById('csr-root');
  var s = data.stats;
  var nSeg = Object.keys(s.por_segmento).length;

  var kpis =
    '<div class="kpi-grid">' +
      kpi('kpi-primary', "window.location='/clientes'", s.total, 'Total Clientes',
        '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>') +
      kpi('kpi-warning', "window.location='/clientes/riesgo'", s.en_riesgo, 'En Riesgo Abandono',
        '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>') +
      kpi('kpi-success', "window.location='/segmentacion'", pesos(s.ingreso_promedio), 'Ingreso Promedio MXN',
        '<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>') +
      kpi('kpi-info', "window.location='/segmentacion'", nSeg, 'Segmentos Activos',
        '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>') +
    '</div>';

  var riesgo = data.clientes_riesgo.map(function (c) {
    var pct = Math.floor((c.riesgo_abandono || 0) * 100);
    return '<a href="/clientes/' + c.id + '/detalle" class="risk-item">' +
      '<div class="risk-avatar">' + esc((c.nombre || '?')[0]) + '</div>' +
      '<div class="risk-info"><span class="risk-name">' + esc(c.nombre) + '</span>' +
      '<span class="risk-seg">' + esc(c.segmento) + ' · ' + esc(c.ciudad) + '</span></div>' +
      '<div class="risk-bar-wrap"><div class="risk-bar" style="width:' + pct + '%"></div>' +
      '<span class="risk-pct">' + pct + '%</span></div></a>';
  }).join('') || '<p class="empty-state">Sin clientes en riesgo alto.</p>';

  var filas = data.campanas.map(function (c) {
    var claseRoi = c.roi > 150 ? 'text-success' : (c.roi > 0 ? 'text-warning' : 'text-danger');
    var claseSeg = 'seg-' + String(c.segmento_objetivo || '').toLowerCase().replace(/ /g, '-');
    return '<tr style="cursor:pointer;" onclick="window.location=\'/campanas/' + c.id + '/detalle\'">' +
      '<td><strong>' + esc(c.nombre) + '</strong></td>' +
      '<td><span class="seg-badge ' + claseSeg + '">' + esc(c.segmento_objetivo) + '</span></td>' +
      '<td>' + esc(c.canal) + '</td><td>' + esc(c.clientes_alcanzados) + '</td>' +
      '<td>' + esc(c.conversiones) + '</td>' +
      '<td class="' + claseRoi + '">' + esc(c.roi) + '%</td>' +
      '<td><span class="status-dot ' + esc(c.estado) + '">' + esc(c.estado) + '</span></td></tr>';
  }).join('') || '<tr><td colspan="7" class="empty-state">No hay campañas.</td></tr>';

  root.innerHTML = kpis +
    '<div class="two-col">' +
      '<div class="card"><div class="card-header"><h3>Distribución por Segmento</h3>' +
      '<a href="/segmentacion" class="card-link">Ver análisis →</a></div>' +
      '<canvas id="segChart" height="220"></canvas></div>' +
      '<div class="card"><div class="card-header"><h3>⚠ Clientes en Riesgo</h3>' +
      '<a href="/clientes/riesgo" class="card-link">Ver todos →</a></div>' +
      '<div class="risk-list">' + riesgo + '</div></div>' +
    '</div>' +
    '<div class="card mt-4"><div class="card-header"><h3>Campañas Recientes</h3>' +
    '<a href="/campanas/nueva" class="btn-sm">+ Nueva</a></div>' +
    '<table class="data-table"><thead><tr><th>Nombre</th><th>Segmento</th><th>Canal</th>' +
    '<th>Clientes</th><th>Conversiones</th><th>ROI</th><th>Estado</th></tr></thead>' +
    '<tbody>' + filas + '</tbody></table></div>';

  dibujarGrafica(s.por_segmento);
}

function kpi(clase, onclick, valor, etiqueta, svgPath) {
  return '<div class="kpi-card ' + clase + '" style="cursor:pointer;" onclick="' + onclick + '">' +
    '<div class="kpi-icon"><svg viewBox="0 0 24 24">' + svgPath + '</svg></div>' +
    '<div class="kpi-data"><span class="kpi-value">' + esc(valor) + '</span>' +
    '<span class="kpi-label">' + etiqueta + '</span></div></div>';
}

// Misma gráfica de dona que en la versión SSR (Chart.js desde CDN).
function dibujarGrafica(porSegmento) {
  if (typeof Chart === 'undefined') return;   // sin internet no hay gráfica
  new Chart(document.getElementById('segChart'), {
    type: 'doughnut',
    data: {
      labels: Object.keys(porSegmento),
      datasets: [{
        data: Object.values(porSegmento),
        backgroundColor: ['#1a56db', '#0e9f6e', '#e3a008', '#f05252', '#7e3af2', '#3f83f8'],
        borderWidth: 3, borderColor: '#fff'
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { position: 'right', labels: { font: { family: 'Plus Jakarta Sans', size: 13 } } } }
    }
  });
}

// Mismo botón "Resegmentar" que en el Dashboard SSR (actualización parcial con fetch).
function resegmentar() {
  fetch('/api/resegmentar').then(function (r) { return r.json(); }).then(function (d) {
    alert('Resegmentación completa. ' + d.total + ' clientes actualizados.');
    location.reload();
  });
}
