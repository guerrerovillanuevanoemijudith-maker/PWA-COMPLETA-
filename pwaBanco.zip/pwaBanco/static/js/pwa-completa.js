/* ===========================================================
   pwa-completa.js - Integración de la PWA en todas las pantallas
   Autora: Noemi Judith Guerrero Villanueva · Matrícula 202204010
   - Registra el Service Worker (si la página aún no lo hizo)
   - Aviso de "sin conexión" y botón "Instalar app"
   - En la pantalla de inicio muestra el estado de la PWA y el
     resumen de datos (módulo modulo-datos.js)
   =========================================================== */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var promptInstalar = null;

  /* ---- Service Worker ---- */
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js', { scope: '/' }).catch(function (e) {
      console.error('[PWA] No se pudo registrar el Service Worker:', e);
    });
  }

  /* ---- Aviso de conexión ---- */
  function bannerRed() {
    var b = $('bannerRed');
    if (!b) {
      b = document.createElement('div');
      b.id = 'bannerRed'; b.className = 'banner-red'; b.hidden = true;
      b.textContent = 'Sin conexión: se muestran los datos guardados en el dispositivo';
      document.body.insertBefore(b, document.body.firstChild);
    }
    return b;
  }
  function actualizarRed() {
    bannerRed().hidden = navigator.onLine;
    if ($('stConexion')) $('stConexion').textContent = navigator.onLine ? 'En línea' : 'Sin conexión';
  }
  window.addEventListener('online', actualizarRed);
  window.addEventListener('offline', actualizarRed);

  /* ---- Instalación ---- */
  function botonInstalar() {
    var b = $('btnInstalar');
    if (!b) {
      b = document.createElement('button');
      b.id = 'btnInstalar'; b.className = 'btn-pwa btn-instalar-flotante'; b.textContent = 'Instalar app'; b.hidden = true;
      document.body.appendChild(b);
    }
    return b;
  }
  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    promptInstalar = e;
    var b = botonInstalar(); b.hidden = false;
    b.onclick = function () {
      b.hidden = true;
      promptInstalar.prompt();
      promptInstalar.userChoice.then(function () { promptInstalar = null; });
    };
  });
  window.addEventListener('appinstalled', function () {
    botonInstalar().hidden = true;
    console.log('[PWA] Aplicación instalada');
  });

  /* ---- Panel de estado y datos (solo en /inicio) ---- */
  function pintarEstado() {
    if (!$('estadoPwa')) return;
    actualizarRed();
    $('stModo').textContent = window.matchMedia('(display-mode: standalone)').matches ? 'Instalada (standalone)' : 'Navegador';
    $('stNotif').textContent = ('Notification' in window) ? Notification.permission : 'no soportadas';
    if (!('serviceWorker' in navigator)) { $('stSw').textContent = 'no soportado'; return; }
    navigator.serviceWorker.ready.then(function (reg) {
      $('stSw').textContent = reg.active ? 'Activo (' + reg.active.state + ')' : 'Instalando…';
      return caches.keys();
    }).then(function (claves) {
      return Promise.all(claves.map(function (k) { return caches.open(k).then(function (c) { return c.keys(); }); }));
    }).then(function (listas) {
      $('stCache').textContent = listas.reduce(function (n, l) { return n + l.length; }, 0);
    }).catch(function () {});
  }

  function pesos(n) { return '$' + Math.round(n || 0).toLocaleString('en-US'); }
  function pintarDatos() {
    if (!$('kpis') || !window.DatosPWA) return;
    DatosPWA.obtenerResumen().then(function (res) {
      if (!res) return;
      var d = res.datos;
      $('kpis').innerHTML =
        '<div class="kpi"><span>Clientes</span><b>' + d.total + '</b></div>' +
        '<div class="kpi"><span>En riesgo de abandono</span><b>' + d.en_riesgo + '</b></div>' +
        '<div class="kpi"><span>Ingreso promedio</span><b>' + pesos(d.ingreso_promedio) + '</b></div>';
      $('origenDatos').textContent = res.origen === 'red'
        ? '(actualizado ahora)'
        : '(guardado en el dispositivo · ' + new Date(res.guardado).toLocaleString('es-MX') + ')';
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    actualizarRed();
    pintarEstado();
    pintarDatos();
  });
})();
