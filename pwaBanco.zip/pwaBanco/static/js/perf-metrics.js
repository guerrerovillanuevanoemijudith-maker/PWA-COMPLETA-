/* ===========================================================
   perf-metrics.js - Auditoría de rendimiento (SSR vs CSR)
   Autora: Noemi Judith Guerrero Villanueva · Matrícula 202204010
   Actividad: Renderizado del lado del servidor (SSR) en una PWA

   Qué hace: mide la carga de la pantalla con la Navigation Timing
   API y la Paint Timing API del propio navegador (sin librerías
   externas) y guarda el resultado en localStorage:
       perf_ssr  -> se guarda al visitar /dashboard
       perf_csr  -> se guarda al visitar /dashboard-csr
   La página /comparativa-ssr-csr lee esas dos claves y las
   muestra lado a lado.

   Métricas capturadas en cada visita:
     TTFB, First Paint, FCP, DOM interactivo, DOMContentLoaded,
     evento load, bytes transferidos del documento, número de
     recursos cargados y "contenido útil visible".

   Uso en la plantilla (data-vista indica qué versión se mide):
     <script src=".../perf-metrics.js" data-vista="ssr"></script>
   =========================================================== */
(function () {
  'use strict';

  var script = document.currentScript;
  var vista = (script && script.dataset.vista) || 'ssr';   // 'ssr' o 'csr'
  var cargado = document.readyState === 'complete';
  // En SSR el contenido ya viene en el HTML; en CSR hay que esperar a que
  // dashboard-csr.js termine de pintar (avisa con el evento "csr:listo").
  var contenidoListo = (vista !== 'csr');
  var contenidoUtilMs = null;
  var intentos = 0;

  function redondear(n) {
    return (typeof n === 'number' && isFinite(n)) ? Math.round(n) : null;
  }

  function capturar() {
    var nav = (performance.getEntriesByType('navigation') || [])[0] || {};
    var pinturas = performance.getEntriesByType('paint') || [];
    var fp = pinturas.filter(function (p) { return p.name === 'first-paint'; })[0];
    var fcp = pinturas.filter(function (p) { return p.name === 'first-contentful-paint'; })[0];

    // Algunos navegadores tardan en publicar el evento de pintado: reintento.
    if (!fcp && intentos < 10) {
      intentos++;
      return setTimeout(capturar, 100);
    }

    var fcpMs = fcp ? fcp.startTime : null;
    var datos = {
      vista: vista,
      fecha: new Date().toISOString(),
      ttfb: redondear(nav.responseStart),
      firstPaint: redondear(fp ? fp.startTime : null),
      fcp: redondear(fcpMs),
      domInteractive: redondear(nav.domInteractive),
      domContentLoaded: redondear(nav.domContentLoadedEventEnd),
      load: redondear(nav.loadEventEnd),
      bytes: redondear(nav.transferSize || nav.encodedBodySize),
      recursos: (performance.getEntriesByType('resource') || []).length,
      // SSR: el contenido útil aparece en el primer pintado con contenido.
      // CSR: aparece hasta que la API respondió y se armó el DOM.
      contenidoUtil: redondear(vista === 'csr' ? contenidoUtilMs : fcpMs)
    };

    try {
      localStorage.setItem('perf_' + vista, JSON.stringify(datos));
    } catch (e) {
      console.warn('[perf-metrics] No se pudo guardar en localStorage:', e);
    }
    mostrarInsignia(datos);
    console.log('[perf-metrics] ' + vista.toUpperCase(), datos);
  }

  function mostrarInsignia(d) {
    var el = document.getElementById('perf-badge');
    if (!el) return;
    el.textContent = '● ' + d.vista.toUpperCase() +
      ' · DOMContentLoaded: ' + d.domContentLoaded + ' ms' +
      ' · Load: ' + d.load + ' ms' +
      ' · FCP: ' + d.fcp + ' ms';
  }

  function intentar() {
    if (cargado && contenidoListo) setTimeout(capturar, 0);
  }

  window.addEventListener('load', function () { cargado = true; intentar(); });
  window.addEventListener('csr:listo', function () {
    contenidoUtilMs = performance.now();
    contenidoListo = true;
    intentar();
  });
  intentar();
})();
