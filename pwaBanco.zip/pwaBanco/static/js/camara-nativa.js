/* ===========================================================
   camara-nativa.js - Característica nativa: cámara del dispositivo
   Autora: Noemi Judith Guerrero Villanueva · Matrícula 202204010
   Actividad: Notificaciones push y acceso a características

   Qué hace:
     - Usa navigator.mediaDevices.getUserMedia() para abrir la
       cámara (el navegador siempre pide permiso primero).
     - Muestra la vista previa en un <video>.
     - Toma una foto dibujando el cuadro actual en un <canvas>
       (por ejemplo, para fotografiar un comprobante del cliente).
     - Permite cambiar entre cámara trasera y frontal.
     - Maneja los errores de permiso: NotAllowedError (negado),
       NotFoundError (no hay cámara), NotReadableError (otra app
       la está usando).
   La foto se queda en el navegador (no se sube al servidor).
   =========================================================== */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var flujo = null;               // MediaStream activo
  var modo = 'environment';       // 'environment' = trasera, 'user' = frontal
  var ultimaFoto = null;          // data URL de la última foto tomada

  function log(msg) {
    var caja = $('pnLog');
    if (!caja) return;
    caja.textContent += '[' + new Date().toLocaleTimeString('es-MX') + '] ' + msg + '\n';
    caja.scrollTop = caja.scrollHeight;
  }

  function aviso(tipo, texto) {
    var el = $('avisoCam');
    el.className = 'pn-aviso ' + tipo;
    el.textContent = texto;
  }

  function chip(estado) {
    var el = $('chipCam');
    el.className = 'pn-chip ' + estado;
    el.textContent = estado;
  }

  /* ---------- estado del permiso de cámara ---------- */
  function leerPermiso() {
    if (!navigator.permissions) { chip('prompt'); return; }
    navigator.permissions.query({ name: 'camera' }).then(function (p) {
      chip(p.state);
      p.onchange = function () { chip(p.state); log('Permiso de cámara cambió a: ' + p.state); };
    }).catch(function () { chip('prompt'); });   // algunos navegadores no soportan 'camera' en permissions
  }

  /* ---------- abrir la cámara ---------- */
  function abrirCamara() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      return aviso('error', 'Este navegador (o conexión sin HTTPS) no permite acceder a la cámara.');
    }
    cerrarCamara(true);
    log('Solicitando cámara con navigator.mediaDevices.getUserMedia()...');
    aviso('info', 'Solicitando acceso a la cámara...');
    navigator.mediaDevices.getUserMedia({
      video: { facingMode: modo, width: { ideal: 1280 }, height: { ideal: 720 } },
      audio: false
    }).then(function (stream) {
      flujo = stream;
      var video = $('camVideo');
      video.srcObject = stream;
      video.style.display = 'block';
      $('camVacio').style.display = 'none';
      var pista = stream.getVideoTracks()[0];
      var ajustes = pista.getSettings();
      log('Cámara abierta: "' + (pista.label || 'sin nombre') + '" ' + (ajustes.width || '?') + 'x' + (ajustes.height || '?'));
      aviso('ok', 'Permiso concedido: la cámara está activa.');
      $('btnFoto').disabled = false;
      $('btnCerrarCam').disabled = false;
      $('btnCambiarCam').disabled = false;
      chip('granted');
    }).catch(function (err) {
      var mensajes = {
        NotAllowedError: 'Permiso denegado: el usuario no permitió el acceso a la cámara. La app sigue funcionando sin ella.',
        NotFoundError: 'No se encontró ninguna cámara en este dispositivo.',
        NotReadableError: 'La cámara está siendo usada por otra aplicación.',
        OverconstrainedError: 'La cámara no cumple con la resolución pedida.',
        SecurityError: 'El navegador bloqueó la cámara por seguridad (se necesita HTTPS o localhost).'
      };
      log('Error de cámara (' + err.name + '): ' + err.message);
      aviso('error', mensajes[err.name] || ('No se pudo abrir la cámara: ' + err.message));
      if (err.name === 'NotAllowedError') chip('denied');
    });
  }

  /* ---------- cerrar la cámara (libera el hardware) ---------- */
  function cerrarCamara(silencioso) {
    if (flujo) {
      flujo.getTracks().forEach(function (t) { t.stop(); });
      flujo = null;
      if (!silencioso) log('Cámara cerrada (se detuvieron las pistas del stream).');
    }
    var video = $('camVideo');
    video.srcObject = null;
    video.style.display = 'none';
    $('camVacio').style.display = 'flex';
    $('btnFoto').disabled = true;
    $('btnCerrarCam').disabled = true;
    $('btnCambiarCam').disabled = true;
    if (!silencioso) aviso('info', 'Cámara cerrada.');
  }

  /* ---------- tomar la foto ---------- */
  function tomarFoto() {
    var video = $('camVideo');
    if (!flujo || !video.videoWidth) return aviso('error', 'Primero abre la cámara.');
    var canvas = $('camCanvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    ultimaFoto = canvas.toDataURL('image/jpeg', 0.9);
    var img = $('camFoto');
    img.src = ultimaFoto;
    $('camFotoBox').style.display = 'block';
    $('btnDescargar').style.display = 'inline-block';
    $('camFotoInfo').textContent = canvas.width + ' x ' + canvas.height + ' px · ' +
      Math.round(ultimaFoto.length * 0.75 / 1024) + ' KB · ' + new Date().toLocaleTimeString('es-MX');
    log('Foto tomada: ' + canvas.width + 'x' + canvas.height + ' px.');
    aviso('ok', 'Foto capturada. Se guarda solo en el navegador; puedes descargarla.');
  }

  function descargarFoto() {
    if (!ultimaFoto) return;
    var a = document.createElement('a');
    a.href = ultimaFoto;
    a.download = 'comprobante-' + Date.now() + '.jpg';
    a.click();
    log('Foto descargada en el dispositivo.');
  }

  function cambiarCamara() {
    modo = (modo === 'environment') ? 'user' : 'environment';
    log('Cambiando a la cámara ' + (modo === 'user' ? 'frontal' : 'trasera') + '...');
    abrirCamara();
  }

  document.addEventListener('DOMContentLoaded', function () {
    if (!$('btnAbrirCam')) return;
    $('btnAbrirCam').addEventListener('click', abrirCamara);
    $('btnFoto').addEventListener('click', tomarFoto);
    $('btnCambiarCam').addEventListener('click', cambiarCamara);
    $('btnCerrarCam').addEventListener('click', function () { cerrarCamara(false); });
    $('btnDescargar').addEventListener('click', descargarFoto);
    leerPermiso();
    // buena práctica: soltar la cámara si el usuario se va de la página
    window.addEventListener('pagehide', function () { cerrarCamara(true); });
  });
})();
