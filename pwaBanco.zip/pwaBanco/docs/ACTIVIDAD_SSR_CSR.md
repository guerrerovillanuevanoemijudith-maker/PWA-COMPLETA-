# Actividad: Renderizado del lado del servidor (SSR) en una PWA

**Alumna:** Noemi Judith Guerrero Villanueva · **Matrícula:** 202204010
**Programa:** Ingeniería en Desarrollo y Gestión de Software · **Grupo:** 10° B (sep–dic 2026)
**Proyecto:** BancoPwaFinanzas — Comparación SSR vs. CSR
**Documento entregado:** `docs/SSR_vs_CSR_BancoPwaFinanzas.pdf`

## Objetivo
Identificar los elementos del renderizado del lado del servidor y desarrollar contenido con SSR.

## Insumos y herramientas sugeridas
- Entorno de ejecución del lado del servidor (Flask + Jinja2).
- Renderizado del lado del cliente (CSR).
- Herramientas de auditoría de rendimiento (Navigation Timing API y Paint Timing API).

## Procedimiento y dónde está cada paso

| Paso | Qué se pide | Dónde está en el proyecto |
|------|-------------|---------------------------|
| 1 | Diferencias CSR vs SSR, carga inicial y SEO | `templates/comparativa_ssr_csr.html` (sección 1) |
| 2 | Vista generada del lado del servidor | Ruta `/dashboard` en `app.py` + `templates/dashboard.html` |
| 3 | Comparar tiempos de primera carga CSR vs SSR | `static/js/perf-metrics.js` + `/comparativa-ssr-csr` |
| 4 | Conclusión: qué conviene en cada parte de la PWA | `templates/comparativa_ssr_csr.html` (sección 4) |

**Producto / entregable:** vista renderizada del lado del servidor (`/dashboard`) y comparación CSR vs. SSR de la misma pantalla (`/dashboard-csr` y `/comparativa-ssr-csr`).

## Archivos agregados
- `templates/dashboard_csr.html` — HTML esqueleto de la versión CSR (`<div id="csr-root">`).
- `templates/comparativa_ssr_csr.html` — página con la actividad, la tabla SSR vs CSR y la conclusión.
- `static/js/dashboard-csr.js` — pide `/api/dashboard-data` y arma el DOM en el navegador.
- `static/js/perf-metrics.js` — mide TTFB, First Paint, FCP, DOM interactivo, DOMContentLoaded, load, bytes, recursos y contenido útil; guarda `perf_ssr` / `perf_csr` en localStorage.
- `static/css/ssr-csr.css` — estilos de la actividad (archivo aparte, no se toca `main.css`).
- `docs/` — este archivo y el PDF de la actividad.

## Archivos existentes con cambios mínimos (solo se agregó, no se quitó nada)
- `app.py` — comentarios en `dashboard()` y las rutas `/dashboard-csr`, `/api/dashboard-data`, `/comparativa-ssr-csr`.
- `templates/dashboard.html` — botones "Ver versión CSR" y "Comparar tiempos", insignia de medición y `perf-metrics.js`.
- `templates/base.html` — entrada "SSR vs CSR" en el menú lateral.

## Cómo probarlo
1. `pip install -r requirements.txt` y `python app.py`
2. Iniciar sesión y abrir **/dashboard** (SSR) y luego **/dashboard-csr** (CSR); cada una guarda su medición.
3. Abrir **/comparativa-ssr-csr** para ver las métricas lado a lado.
4. Para medir sin caché del Service Worker: recarga forzada (Ctrl+Shift+R) o "Disable cache" en DevTools.
