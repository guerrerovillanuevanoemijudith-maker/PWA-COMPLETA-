# Actividad: PWA completa publicada

**Alumna:** Noemi Judith Guerrero Villanueva · Matrícula 202204010
**Materia:** Desarrollo de Dispositivos Inteligentes

## Qué se integró en una sola PWA

| Componente | Dónde está |
|---|---|
| App shell | `templates/base.html` + `static/css/main.css` + precarga en `static/sw.js` |
| Manifiesto | `static/manifest.json` (start_url `/inicio?source=pwa`) |
| Splash / Home | `templates/splash.html`, `templates/home.html`, `pwa_completa.py` |
| Vista SSR / CSR | `/dashboard` (SSR) y `/dashboard-csr` (CSR) |
| Módulo de datos | `static/js/modulo-datos.js` (IndexedDB) + `/api/pwa/resumen` |
| Service Worker offline | `static/sw.js` (versión v2) |
| Notificaciones push | `static/js/push-nativo.js` + `/api/push/*` |

## Publicación

Render (HTTPS automático) con `render.yaml` / `Procfile`; también queda la
configuración de Google Cloud (`app.yaml`) de la actividad anterior.

## Pruebas

- `python -m pytest tests -v` → pruebas del servidor (11).
- `python tests/e2e_navegador.py <URL>` → instalable, offline y push en Chromium (15).
