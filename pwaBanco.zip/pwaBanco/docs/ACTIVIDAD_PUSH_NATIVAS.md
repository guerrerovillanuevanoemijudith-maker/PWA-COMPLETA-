# Actividad: Notificaciones push y acceso a características nativas

**Alumna:** Noemi Judith Guerrero Villanueva · **Matrícula:** 202204010
**Programa:** Ingeniería en Desarrollo y Gestión de Software · **Grupo:** 10° B (sep–dic 2026)
**Proyecto:** BancoPwaFinanzas (FinancePWA)

## Objetivo
Programar notificaciones push y el acceso a características nativas del dispositivo desde la PWA.

## Procedimiento y dónde está cada paso

| Paso | Qué se pide | Dónde está en el proyecto |
|------|-------------|---------------------------|
| 1 | Explicar push y su flujo de suscripción | `templates/notificaciones_nativas.html` (sección 1) |
| 2 | Permiso y notificación de prueba | `static/js/push-nativo.js` + eventos `push` y `notificationclick` en `static/sw.js` + rutas `/api/push/*` en `app.py` |
| 3 | Característica nativa (geolocalización) | `static/js/push-nativo.js` (`obtenerUbicacion`) |
| 3.1 | Segunda característica nativa (cámara) | `static/js/camara-nativa.js` (`getUserMedia`, tomar foto, cambiar cámara) |
| 4 | Comportamiento al conceder o negar permisos | `static/js/push-nativo.js` (estados granted / denied / default y errores de geolocalización) |

**Producto / entregable:** página `/notificaciones-nativas` con notificaciones push, geolocalización y cámara, con manejo de permisos.

## Archivos agregados
- `templates/notificaciones_nativas.html` — página de la actividad.
- `static/js/push-nativo.js` — permisos, notificación de prueba, suscripción push y geolocalización.
- `static/css/push-nativo.css` — estilos de la actividad (archivo aparte, no se toca `main.css`).
- `static/js/camara-nativa.js` y `static/css/camara-nativa.css` — API de cámara (vista previa, foto, cambiar cámara, errores de permiso).
- `instance/vapid_private.pem` y `instance/vapid_public.txt` — claves VAPID de desarrollo.
- `docs/ACTIVIDAD_PUSH_NATIVAS.md` — este archivo.

## Archivos existentes con cambios mínimos (solo se agregó, no se quitó nada)
- `app.py` — rutas `/notificaciones-nativas`, `/api/push/clave`, `/api/push/suscribir`, `/api/push/enviar-prueba`.
- `static/sw.js` — eventos `push` y `notificationclick` al final del archivo.
- `templates/base.html` — entrada "Push y nativas" en el menú lateral.
- `templates/notificaciones_nativas.html` — se agregó la tarjeta 3.1 (cámara), el estado de permiso de cámara y su fila en la tabla del paso 4.
- `requirements.txt` — se agregó `pywebpush`.

## Cómo probarlo
1. `pip install -r requirements.txt` y `python app.py`
2. Iniciar sesión y abrir **/notificaciones-nativas** (en `localhost` o con HTTPS, que es lo que exigen estas APIs).
3. Pulsar "Solicitar permiso" y "Notificación de prueba"; después "Suscribirme a push" y "Enviar push desde el servidor".
4. Pulsar "Obtener mi ubicación".
4.1. En la tarjeta 3.1 pulsar "Abrir cámara", aceptar el permiso, "Tomar foto" y, si se quiere, "Descargar foto". La cámara también exige `localhost` o HTTPS.
5. Para probar el caso de permiso denegado: bloquear Notificaciones, Ubicación y Cámara desde el candado de la barra de direcciones y repetir los botones.
6. Crear la suscripción push necesita internet (el navegador usa el servicio push del fabricante); la notificación de prueba y la ubicación funcionan sin eso. El evento `push` también se puede probar con DevTools > Application > Service Workers > Push.
