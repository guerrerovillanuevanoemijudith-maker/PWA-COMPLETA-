# Opción "Descargar aplicación"

**Autora:** Noemi Judith Guerrero Villanueva · Matrícula 202204010
**Fecha:** 11 de octubre de 2026

Se agregó una opción visible para descargar (instalar) la PWA en el dispositivo.
No se modificó ninguna funcionalidad anterior: solo se sumó un archivo nuevo y una
línea `<script>` en cuatro plantillas.

| Archivo | Cambio |
|---|---|
| `static/js/descargar-app.js` | **Nuevo.** Crea el botón y la ventana con instrucciones. |
| `templates/base.html`, `home.html`, `login.html`, `registro.html` | Una línea que carga el script. |
| `tests/test_descargar_app.py` | **Nuevo.** 3 pruebas automáticas. |

## Cómo funciona

- **Chrome / Edge (Android y computadora):** el botón abre el cuadro de instalación del sistema
  (evento `beforeinstallprompt`).
- **iPhone / iPad (Safari) y navegadores sin el evento:** muestra una ventana con los pasos manuales
  (Compartir → Añadir a pantalla de inicio, o menú → Instalar aplicación).
- **Ya instalada:** el botón no se muestra.
- **Dónde aparece:** botón "Descargar aplicación" en la pantalla de inicio (`/inicio`),
  opción "Descargar app" en el menú lateral y botón flotante en login y registro.
