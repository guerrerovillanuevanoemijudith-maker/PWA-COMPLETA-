"""
BancoMexicoFinance - Sistema de Segmentación de Clientes
IA Gratuita integrada: FinancuerAI (sin API key requerida)
"""

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import json
import os
import random
import math
import re
import urllib.parse
import urllib.request

# ─── Configuración de la app ───────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "bancomexicofinance-dev-secret-2024")

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
app.config["SQLALCHEMY_DATABASE_URI"] = (
    "sqlite:///" + os.path.join(BASE_DIR, "instance", "bancofinanciero.db")
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

print("[OK] FinancuerAI configurado correctamente — IA gratuita integrada")

# ─── Modelos ───────────────────────────────────────────────────────────────────

class Usuario(db.Model):
    __tablename__ = "usuarios"
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    rol = db.Column(db.String(20), default="analista")
    creado_en = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, pw):
        self.password_hash = generate_password_hash(pw)

    def check_password(self, pw):
        return check_password_hash(self.password_hash, pw)


class Cliente(db.Model):
    __tablename__ = "clientes"
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(150))
    edad = db.Column(db.Integer)
    genero = db.Column(db.String(10))
    ciudad = db.Column(db.String(80))
    ocupacion = db.Column(db.String(80))
    ingreso_mensual = db.Column(db.Float, default=0.0)
    saldo_cuenta = db.Column(db.Float, default=0.0)
    score_credito = db.Column(db.Integer, default=600)
    num_productos = db.Column(db.Integer, default=1)
    antiguedad_meses = db.Column(db.Integer, default=1)
    num_transacciones_mes = db.Column(db.Integer, default=0)
    monto_promedio_transaccion = db.Column(db.Float, default=0.0)
    tiene_hipoteca = db.Column(db.Boolean, default=False)
    tiene_inversion = db.Column(db.Boolean, default=False)
    tiene_seguro = db.Column(db.Boolean, default=False)
    canal_preferido = db.Column(db.String(20), default="digital")
    riesgo_abandono = db.Column(db.Float, default=0.0)
    segmento = db.Column(db.String(40), default="Pendiente")
    subsegmento = db.Column(db.String(60), default="")
    score_propension = db.Column(db.Float, default=0.0)
    creado_en = db.Column(db.DateTime, default=datetime.utcnow)
    actualizado_en = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "nombre": self.nombre,
            "email": self.email,
            "edad": self.edad,
            "genero": self.genero,
            "ciudad": self.ciudad,
            "ocupacion": self.ocupacion,
            "ingreso_mensual": self.ingreso_mensual,
            "saldo_cuenta": self.saldo_cuenta,
            "score_credito": self.score_credito,
            "num_productos": self.num_productos,
            "antiguedad_meses": self.antiguedad_meses,
            "num_transacciones_mes": self.num_transacciones_mes,
            "monto_promedio_transaccion": self.monto_promedio_transaccion,
            "tiene_hipoteca": self.tiene_hipoteca,
            "tiene_inversion": self.tiene_inversion,
            "tiene_seguro": self.tiene_seguro,
            "canal_preferido": self.canal_preferido,
            "riesgo_abandono": self.riesgo_abandono,
            "segmento": self.segmento,
            "subsegmento": self.subsegmento,
            "score_propension": self.score_propension,
        }


class Campana(db.Model):
    __tablename__ = "campanas"
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(120), nullable=False)
    segmento_objetivo = db.Column(db.String(60))
    canal = db.Column(db.String(30))
    presupuesto = db.Column(db.Float, default=0.0)
    clientes_alcanzados = db.Column(db.Integer, default=0)
    conversiones = db.Column(db.Integer, default=0)
    roi = db.Column(db.Float, default=0.0)
    estado = db.Column(db.String(20), default="activa")
    creado_en = db.Column(db.DateTime, default=datetime.utcnow)


# ─── Motor de Microsegmentación ────────────────────────────────────────────────

def calcular_segmento(cliente: Cliente):
    score = 0
    subseg = []

    if cliente.ingreso_mensual >= 80000:
        wealth = "Premium"
        score += 40
    elif cliente.ingreso_mensual >= 30000:
        wealth = "Medio-Alto"
        score += 25
    elif cliente.ingreso_mensual >= 10000:
        wealth = "Medio"
        score += 15
    else:
        wealth = "Básico"
        score += 5

    if cliente.score_credito >= 750:
        score += 20
        subseg.append("Excelente Crédito")
    elif cliente.score_credito >= 650:
        score += 12
        subseg.append("Buen Crédito")
    else:
        score += 3
        subseg.append("Crédito en Desarrollo")

    if cliente.num_transacciones_mes >= 20:
        score += 15
        subseg.append("Alta Actividad")
    elif cliente.num_transacciones_mes >= 10:
        score += 8
        subseg.append("Actividad Moderada")
    else:
        score += 2
        subseg.append("Baja Actividad")

    if cliente.antiguedad_meses >= 60:
        score += 10
        subseg.append("Cliente Leal")
    elif cliente.antiguedad_meses >= 24:
        score += 6
    else:
        score += 1
        subseg.append("Cliente Nuevo")

    score += min(cliente.num_productos * 3, 15)

    abandono = max(0.0, min(1.0, 1 - (score / 100)))
    if cliente.num_transacciones_mes == 0:
        abandono = min(abandono + 0.3, 1.0)
    cliente.riesgo_abandono = round(abandono, 2)
    cliente.score_propension = round(score / 100, 2)

    if wealth == "Premium" and score >= 70:
        seg = "Premium"
    elif score >= 55:
        seg = "Alto Valor"
    elif score >= 35:
        seg = "Medio"
    elif score >= 20:
        seg = "Básico"
    else:
        seg = "En Riesgo"

    cliente.segmento = seg
    cliente.subsegmento = " | ".join(subseg[:3])
    return cliente


# ─── Helpers ───────────────────────────────────────────────────────────────────

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated


def get_stats():
    total = Cliente.query.count()
    por_seg = db.session.query(Cliente.segmento, db.func.count(Cliente.id)).group_by(Cliente.segmento).all()
    en_riesgo = Cliente.query.filter(Cliente.riesgo_abandono >= 0.6).count()
    ingreso_prom = db.session.query(db.func.avg(Cliente.ingreso_mensual)).scalar() or 0
    return {
        "total": total,
        "por_segmento": {s: c for s, c in por_seg},
        "en_riesgo": en_riesgo,
        "ingreso_promedio": round(ingreso_prom, 2),
    }


# ─── IA Gratuita: Motor de respuestas inteligentes ────────────────────────────

def respuesta_ia_local(mensaje, stats, riesgo_nombres, canales_info, campanas_all):
    """
    Motor de IA local gratuito para BancoMexicoFinance.
    Analiza la pregunta y genera respuestas contextuales precisas con datos reales.
    """
    msg = mensaje.lower().strip()
    seg_info = stats["por_segmento"]
    total = stats["total"]
    en_riesgo = stats["en_riesgo"]
    ingreso_prom = stats["ingreso_promedio"]

    camp_activas = [c for c in campanas_all if c.estado == "activa"]
    camp_completadas = [c for c in campanas_all if c.estado == "completada"]
    roi_prom = round(sum(c.roi for c in campanas_all) / len(campanas_all), 1) if campanas_all else 0
    seg_max = max(seg_info, key=seg_info.get) if seg_info else "N/D"
    seg_min = min(seg_info, key=seg_info.get) if seg_info else "N/D"

    # ── Preguntas sobre clientes en riesgo ──
    if any(x in msg for x in ["riesgo", "abandono", "abandonar", "fuga", "perder"]):
        porcentaje = round((en_riesgo / total * 100), 1) if total > 0 else 0
        top3 = ", ".join(riesgo_nombres[:3]) if riesgo_nombres else "ninguno crítico identificado"
        return (
            f"⚠️ Actualmente hay **{en_riesgo} clientes en riesgo de abandono** ({porcentaje}% del total).\n\n"
            f"Los más críticos son: {top3}.\n\n"
            f"**Recomendación:** Activar campaña de retención inmediata por canal preferido de cada cliente. "
            f"Los segmentos 'En Riesgo' y 'Básico' requieren atención prioritaria con incentivos personalizados."
        )

    # ── Preguntas sobre segmentos ──
    elif any(x in msg for x in ["segment", "distribuc", "cuántos hay", "cuantos hay", "grupos"]):
        seg_detalle = "\n".join([f"  • **{s}**: {c} clientes" for s, c in seg_info.items()])
        return (
            f"📊 El sistema tiene **{total} clientes** distribuidos en {len(seg_info)} segmentos:\n\n"
            f"{seg_detalle}\n\n"
            f"El segmento más grande es **{seg_max}** con {seg_info.get(seg_max, 0)} clientes. "
            f"La microsegmentación usa modelo RFM + Score Crediticio + Antigüedad en tiempo real."
        )

    # ── Pregunta sobre segmento con más clientes ──
    elif any(x in msg for x in ["más clientes", "mas clientes", "mayor", "top segmento", "mejor segmento"]):
        return (
            f"🏆 El segmento con **más clientes** es **{seg_max}** con **{seg_info.get(seg_max, 0)} clientes**.\n\n"
            f"Distribución completa: {', '.join([f'{s} ({c})' for s,c in seg_info.items()])}.\n\n"
            f"**Estrategia recomendada para {seg_max}:** "
            + ("Cross-sell de productos de inversión y seguros premium." if seg_max == "Premium"
               else "Upgrades y productos de mayor valor agregado." if seg_max == "Alto Valor"
               else "Educación financiera digital y activación de productos." if seg_max == "Medio"
               else "Onboarding digital y activación básica." if seg_max == "Básico"
               else "Retención urgente con incentivos personalizados.")
        )

    # ── Preguntas sobre canales ──
    elif any(x in msg for x in ["canal", "comunicac", "digital", "móvil", "sucursal", "telefon"]):
        canales_str = "\n".join([f"  • **{k}**: {v} clientes" for k, v in canales_info.items()])
        canal_top = max(canales_info, key=canales_info.get) if canales_info else "digital"
        return (
            f"📱 Distribución de canales preferidos:\n\n{canales_str}\n\n"
            f"El canal más usado es **{canal_top}** con {canales_info.get(canal_top, 0)} clientes. "
            f"**Recomendación:** Personalizar el canal de cada campaña según las preferencias de cada segmento para maximizar conversiones."
        )

    # ── Preguntas sobre campañas ──
    elif any(x in msg for x in ["campaña", "campana", "marketing", "roi", "conversión", "conversion"]):
        if not campanas_all:
            return "📢 Aún no hay campañas creadas. Te recomiendo crear una campaña de retención para los clientes en riesgo como primera acción."
        camp_str = "\n".join([f"  • **{c.nombre}** → segmento {c.segmento_objetivo}, canal {c.canal}, ROI {c.roi}%, estado: {c.estado}" for c in campanas_all])
        return (
            f"📢 **{len(campanas_all)} campañas** en el sistema ({len(camp_activas)} activas, {len(camp_completadas)} completadas):\n\n"
            f"{camp_str}\n\n"
            f"ROI promedio del sistema: **{roi_prom}%**. "
            f"Las campañas activas están alcanzando a {sum(c.clientes_alcanzados for c in camp_activas)} clientes."
        )

    # ── Preguntas sobre ingresos / finanzas ──
    elif any(x in msg for x in ["ingreso", "salario", "sueldo", "dinero", "promedio", "financiero", "finanzas"]):
        return (
            f"💰 El **ingreso mensual promedio** de los clientes es de **${ingreso_prom:,.0f} MXN**.\n\n"
            f"Los clientes **Premium** tienen ingresos superiores a $80,000 MXN y representan "
            f"{seg_info.get('Premium', 0)} clientes con alta propensión a productos de inversión.\n\n"
            f"**Oportunidad:** Los {seg_info.get('Alto Valor', 0)} clientes de 'Alto Valor' son candidatos ideales "
            f"para upgrades y productos de mayor rendimiento."
        )

    # ── Resumen general ──
    elif any(x in msg for x in ["resumen", "estado", "cómo está", "como esta", "panorama", "overview", "general", "sistema"]):
        return (
            f"📋 **Resumen BancoMexicoFinance:**\n\n"
            f"  • **Total clientes:** {total}\n"
            f"  • **En riesgo de abandono:** {en_riesgo} ({round(en_riesgo/total*100,1) if total else 0}%)\n"
            f"  • **Ingreso promedio:** ${ingreso_prom:,.0f} MXN\n"
            f"  • **Campañas activas:** {len(camp_activas)}\n"
            f"  • **Segmento principal:** {seg_max} ({seg_info.get(seg_max,0)} clientes)\n\n"
            f"El sistema opera con microsegmentación RFM en tiempo real. "
            f"Prioridad actual: atender a los **{en_riesgo} clientes en riesgo** y maximizar el ROI de las campañas activas."
        )

    # ── Recomendaciones / estrategia ──
    elif any(x in msg for x in ["recomienda", "estrategia", "qué hacer", "que hacer", "acción", "accion", "mejorar", "sugerir"]):
        return (
            f"💡 **Recomendaciones estratégicas:**\n\n"
            f"1. **Retención urgente:** Contactar a los {en_riesgo} clientes en riesgo por su canal preferido en las próximas 48h.\n"
            f"2. **Cross-sell Premium:** Los {seg_info.get('Premium', 0)} clientes Premium tienen alta propensión a inversiones y seguros.\n"
            f"3. **Activación digital:** Migrar clientes de sucursal al canal digital para reducir costos operativos.\n"
            f"4. **Campaña de segmento Medio:** {seg_info.get('Medio', 0)} clientes con potencial de upgrade mediante educación financiera.\n\n"
            f"ROI esperado con estas acciones: superior al {roi_prom}% actual."
        )

    # ── Preguntas sobre el sistema / cómo funciona ──
    elif any(x in msg for x in ["cómo funciona", "como funciona", "qué es", "que es", "para qué", "para que", "herramienta"]):
        return (
            f"🏦 **BancoMexicoFinance** es una plataforma de microsegmentación de clientes bancarios.\n\n"
            f"Usa un modelo **RFM + Score Crediticio + Comportamiento** para clasificar clientes en tiempo real: "
            f"Premium, Alto Valor, Medio, Básico y En Riesgo. Cada cliente se evalúa por ingresos, "
            f"antigüedad, transacciones y score crediticio.\n\n"
            f"Actualmente gestiona **{total} clientes** con {len(campanas_all)} campañas y actualización automática de segmentos."
        )

    # ── Saludo ──
    elif any(x in msg for x in ["hola", "buenas", "buenos", "hey", "qué tal", "que tal"]):
        return (
            f"¡Hola! Soy **FinancuerAI**, el asistente de BancoMexicoFinance. 👋\n\n"
            f"Tenemos **{total} clientes** activos, **{en_riesgo} en riesgo** de abandono y "
            f"**{len(camp_activas)} campañas** activas. ¿En qué puedo ayudarte hoy?\n\n"
            f"Puedo responderte sobre clientes, segmentos, campañas, canales, ingresos y estrategias de retención."
        )

    # ── Respuesta genérica con datos reales ──
    else:
        return (
            f"Entiendo tu pregunta sobre **\"{mensaje}\"**. Con los datos del sistema puedo decirte:\n\n"
            f"📊 Actualmente gestionamos **{total} clientes** distribuidos en segmentos: "
            f"{', '.join([f'{s} ({c})' for s,c in seg_info.items()])}.\n\n"
            f"Hay **{en_riesgo} clientes en riesgo** de abandono y **{len(camp_activas)} campañas activas** "
            f"con ROI promedio de {roi_prom}%. ¿Quieres que profundice en algún aspecto específico: "
            f"clientes en riesgo, segmentación, campañas o estrategias?"
        )


# ─── Rutas ─────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        email = request.form.get("email", "").strip()
        pw = request.form.get("password", "")
        user = Usuario.query.filter_by(email=email).first()
        if user and user.check_password(pw):
            session["user_id"] = user.id
            session["user_nombre"] = user.nombre
            session["user_rol"] = user.rol
            return redirect(url_for("dashboard"))
        error = "Credenciales incorrectas. Intenta de nuevo."
    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/registro", methods=["GET", "POST"])
def registro():
    error = None
    success = None
    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        email = request.form.get("email", "").strip()
        pw = request.form.get("password", "")
        pw2 = request.form.get("password2", "")
        if not nombre or not email or not pw:
            error = "Todos los campos son obligatorios."
        elif pw != pw2:
            error = "Las contraseñas no coinciden."
        elif Usuario.query.filter_by(email=email).first():
            error = "Ya existe una cuenta con ese correo."
        else:
            nuevo = Usuario(nombre=nombre, email=email, rol="analista")
            nuevo.set_password(pw)
            db.session.add(nuevo)
            db.session.commit()
            session["user_id"] = nuevo.id
            session["user_nombre"] = nuevo.nombre
            session["user_rol"] = nuevo.rol
            return redirect(url_for("dashboard"))
    return render_template("registro.html", error=error, success=success)


@app.route("/dashboard")
@login_required
def dashboard():
    stats = get_stats()
    campanas = Campana.query.order_by(Campana.creado_en.desc()).limit(5).all()
    clientes_riesgo = Cliente.query.filter(Cliente.riesgo_abandono >= 0.6).order_by(Cliente.riesgo_abandono.desc()).limit(8).all()
    # [ACTIVIDAD SSR - Paso 2] Vista generada del lado del servidor.
    # Flask/Jinja2 arma el HTML final AQUÍ, en el servidor, con los datos
    # (KPIs, campañas y clientes en riesgo) ya incrustados en las etiquetas.
    # El navegador recibe la pantalla completa: no necesita otra petición.
    # Plantilla: templates/dashboard.html  ->  esto es SSR.
    return render_template("dashboard.html", stats=stats, campanas=campanas, clientes_riesgo=clientes_riesgo)


# ═══════════════════════════════════════════════════════════════════════════════
# ACTIVIDAD: Renderizado del lado del servidor (SSR) en una PWA
# Proyecto: BancoPwaFinanzas — Comparación SSR vs. CSR
# Alumna: Noemi Judith Guerrero Villanueva · Matrícula 202204010
# Ing. en Desarrollo y Gestión de Software · Grupo 10° B · Sep–Dic 2026
#
# Objetivo: identificar los elementos del renderizado del lado del servidor y
# desarrollar contenido con SSR.
#
# Dónde está cada paso del procedimiento:
#   1) Diferencias CSR vs SSR, carga inicial y SEO -> templates/comparativa_ssr_csr.html
#   2) Vista SSR (contenido ya renderizado)         -> ruta /dashboard  (arriba)
#                                                      + templates/dashboard.html
#   3) Comparar tiempos de primera carga            -> static/js/perf-metrics.js
#                                                      + /comparativa-ssr-csr
#   4) Conclusión: qué conviene en cada parte       -> templates/comparativa_ssr_csr.html
#
# Lo que se agregó para poder comparar la MISMA pantalla con CSR:
#   - /dashboard-csr        HTML esqueleto (sin datos)   -> dashboard_csr.html
#   - /api/dashboard-data   JSON puro que lo alimenta
#   - static/js/dashboard-csr.js  construye el DOM en el navegador
#   - static/js/perf-metrics.js   Navigation Timing API + Paint Timing API
#   - /comparativa-ssr-csr  muestra las métricas SSR y CSR lado a lado
# ═══════════════════════════════════════════════════════════════════════════════

@app.route("/dashboard-csr")
@login_required
def dashboard_csr():
    # [ACTIVIDAD CSR] El servidor NO consulta la base de datos aquí.
    # Solo entrega el HTML "esqueleto" (#csr-root vacío). Los datos los pide
    # después el navegador con fetch() a /api/dashboard-data.
    return render_template("dashboard_csr.html")


@app.route("/api/dashboard-data")
@login_required
def api_dashboard_data():
    # Aquí SÍ se consulta la BD (mismas consultas que /dashboard), pero se
    # devuelve JSON puro, sin HTML. El navegador decide cómo pintarlo (CSR).
    stats = get_stats()
    campanas = Campana.query.order_by(Campana.creado_en.desc()).limit(5).all()
    clientes_riesgo = Cliente.query.filter(
        Cliente.riesgo_abandono >= 0.6
    ).order_by(Cliente.riesgo_abandono.desc()).limit(8).all()
    return jsonify({
        "stats": stats,
        "campanas": [{
            "id": c.id,
            "nombre": c.nombre,
            "segmento_objetivo": c.segmento_objetivo,
            "canal": c.canal,
            "clientes_alcanzados": c.clientes_alcanzados,
            "conversiones": c.conversiones,
            "roi": c.roi,
            "estado": c.estado,
        } for c in campanas],
        "clientes_riesgo": [{
            "id": c.id,
            "nombre": c.nombre,
            "segmento": c.segmento,
            "ciudad": c.ciudad,
            "riesgo_abandono": c.riesgo_abandono,
        } for c in clientes_riesgo],
    })


@app.route("/comparativa-ssr-csr")
@login_required
def comparativa_ssr_csr():
    # Página estática: las métricas las lee el navegador desde localStorage
    # (claves perf_ssr y perf_csr, que guarda static/js/perf-metrics.js).
    return render_template("comparativa_ssr_csr.html")


@app.route("/clientes")
@login_required
def clientes():
    q = request.args.get("q", "")
    seg = request.args.get("segmento", "")
    page = int(request.args.get("page", 1))
    query = Cliente.query
    if q:
        query = query.filter(Cliente.nombre.ilike(f"%{q}%"))
    if seg:
        query = query.filter(Cliente.segmento == seg)
    pagination = query.order_by(Cliente.nombre.asc()).paginate(page=page, per_page=15, error_out=False)
    offset = (page - 1) * 15
    segmentos = [s[0] for s in db.session.query(Cliente.segmento).distinct().all()]
    return render_template("clientes.html", pagination=pagination, segmentos=segmentos, q=q, seg_actual=seg, offset=offset)


@app.route("/clientes/nuevo", methods=["GET", "POST"])
@login_required
def nuevo_cliente():
    if request.method == "POST":
        c = Cliente(
            nombre=request.form["nombre"],
            email=request.form.get("email"),
            edad=int(request.form.get("edad") or 0),
            genero=request.form.get("genero"),
            ciudad=request.form.get("ciudad"),
            ocupacion=request.form.get("ocupacion"),
            ingreso_mensual=float(request.form.get("ingreso_mensual") or 0),
            saldo_cuenta=float(request.form.get("saldo_cuenta") or 0),
            score_credito=int(request.form.get("score_credito") or 600),
            num_productos=int(request.form.get("num_productos") or 1),
            antiguedad_meses=int(request.form.get("antiguedad_meses") or 1),
            num_transacciones_mes=int(request.form.get("num_transacciones_mes") or 0),
            monto_promedio_transaccion=float(request.form.get("monto_promedio_transaccion") or 0),
            tiene_hipoteca="tiene_hipoteca" in request.form,
            tiene_inversion="tiene_inversion" in request.form,
            tiene_seguro="tiene_seguro" in request.form,
            canal_preferido=request.form.get("canal_preferido", "digital"),
        )
        c = calcular_segmento(c)
        db.session.add(c)
        db.session.commit()
        flash("Cliente agregado correctamente.", "success")
        return redirect(url_for("clientes"))
    return render_template("form_cliente.html", cliente=None)


@app.route("/clientes/<int:cid>/editar", methods=["GET", "POST"])
@login_required
def editar_cliente(cid):
    c = Cliente.query.get_or_404(cid)
    if request.method == "POST":
        c.nombre = request.form["nombre"]
        c.email = request.form.get("email")
        c.edad = int(request.form.get("edad") or 0)
        c.genero = request.form.get("genero")
        c.ciudad = request.form.get("ciudad")
        c.ocupacion = request.form.get("ocupacion")
        c.ingreso_mensual = float(request.form.get("ingreso_mensual") or 0)
        c.saldo_cuenta = float(request.form.get("saldo_cuenta") or 0)
        c.score_credito = int(request.form.get("score_credito") or 600)
        c.num_productos = int(request.form.get("num_productos") or 1)
        c.antiguedad_meses = int(request.form.get("antiguedad_meses") or 1)
        c.num_transacciones_mes = int(request.form.get("num_transacciones_mes") or 0)
        c.monto_promedio_transaccion = float(request.form.get("monto_promedio_transaccion") or 0)
        c.tiene_hipoteca = "tiene_hipoteca" in request.form
        c.tiene_inversion = "tiene_inversion" in request.form
        c.tiene_seguro = "tiene_seguro" in request.form
        c.canal_preferido = request.form.get("canal_preferido", "digital")
        c = calcular_segmento(c)
        db.session.commit()
        flash("Cliente actualizado.", "success")
        return redirect(url_for("clientes"))
    return render_template("form_cliente.html", cliente=c)


@app.route("/clientes/riesgo")
@login_required
def clientes_riesgo():
    clientes_en_riesgo = Cliente.query.filter(Cliente.riesgo_abandono >= 0.6).order_by(Cliente.riesgo_abandono.desc()).all()
    total = Cliente.query.count()
    clientes_sin_riesgo = Cliente.query.filter(Cliente.riesgo_abandono < 0.6).order_by(Cliente.nombre.asc()).all()
    clientes_sin_riesgo_data = [{"id": c.id, "nombre": c.nombre, "segmento": c.segmento, "ciudad": c.ciudad, "riesgo_abandono": c.riesgo_abandono} for c in clientes_sin_riesgo]
    return render_template("clientes_riesgo.html", clientes_riesgo=clientes_en_riesgo, total=total, clientes_sin_riesgo=clientes_sin_riesgo_data)


@app.route("/clientes/<int:cid>/eliminar", methods=["POST"])
@login_required
def eliminar_cliente(cid):
    c = Cliente.query.get_or_404(cid)
    db.session.delete(c)
    db.session.commit()
    flash("Cliente eliminado.", "info")
    return redirect(url_for("clientes"))


@app.route("/clientes/<int:cid>/detalle")
@login_required
def detalle_cliente(cid):
    c = Cliente.query.get_or_404(cid)
    return render_template("detalle_cliente.html", cliente=c)


@app.route("/segmentacion")
@login_required
def segmentacion():
    stats = get_stats()
    clientes_all = Cliente.query.all()
    data_chart = json.dumps(stats["por_segmento"])
    return render_template("segmentacion.html", stats=stats, data_chart=data_chart, clientes=clientes_all)


@app.route("/campanas")
@login_required
def campanas():
    items = Campana.query.order_by(Campana.creado_en.desc()).all()
    return render_template("campanas.html", campanas=items)


@app.route("/campanas/<int:camp_id>/detalle")
@login_required
def detalle_campana(camp_id):
    camp = Campana.query.get_or_404(camp_id)
    clientes_seg = Cliente.query.filter_by(segmento=camp.segmento_objetivo).order_by(Cliente.nombre.asc()).limit(camp.clientes_alcanzados).all()
    return render_template("detalle_campana.html", camp=camp, clientes=clientes_seg)


@app.route("/campanas/nueva", methods=["GET", "POST"])
@login_required
def nueva_campana():
    segmentos = [s[0] for s in db.session.query(Cliente.segmento).distinct().all()]
    if request.method == "POST":
        seg = request.form["segmento_objetivo"]
        presupuesto = float(request.form.get("presupuesto") or 0)
        canal = request.form.get("canal", "email")
        n_clientes = Cliente.query.filter_by(segmento=seg).count()
        tasa_conv = 0.18 if seg == "Premium" else (0.12 if seg == "Alto Valor" else 0.07)
        conversiones = int(n_clientes * tasa_conv)
        roi_est = round(((conversiones * 1500) - presupuesto) / max(presupuesto, 1) * 100, 1)
        camp = Campana(
            nombre=request.form["nombre"],
            segmento_objetivo=seg,
            canal=canal,
            presupuesto=presupuesto,
            clientes_alcanzados=n_clientes,
            conversiones=conversiones,
            roi=roi_est,
        )
        db.session.add(camp)
        db.session.commit()
        flash(f"Campaña creada. ROI estimado: {roi_est}%", "success")
        return redirect(url_for("campanas"))
    return render_template("nueva_campana.html", segmentos=segmentos)


# ─── API ───────────────────────────────────────────────────────────────────────

@app.route("/api/stats")
@login_required
def api_stats():
    return jsonify(get_stats())


@app.route("/api/resegmentar")
@login_required
def api_resegmentar():
    clientes = Cliente.query.all()
    for c in clientes:
        calcular_segmento(c)
    db.session.commit()
    return jsonify({"ok": True, "total": len(clientes)})


@app.route("/api/chat", methods=["POST"])
@login_required
def api_chat():
    data = request.get_json()
    mensaje = data.get("mensaje", "").strip()
    if not mensaje:
        return jsonify({"respuesta": "Por favor escribe algo para ayudarte."})

    stats = get_stats()

    # Datos enriquecidos del sistema
    clientes_riesgo_lista = Cliente.query.filter(
        Cliente.riesgo_abandono >= 0.6
    ).order_by(Cliente.riesgo_abandono.desc()).limit(5).all()
    riesgo_nombres = [f"{c.nombre} ({c.segmento}, riesgo {int(c.riesgo_abandono*100)}%)" for c in clientes_riesgo_lista]

    canales_raw = db.session.query(
        Cliente.canal_preferido, db.func.count(Cliente.id)
    ).group_by(Cliente.canal_preferido).all()
    canales_info = {canal: count for canal, count in canales_raw}

    campanas_all = Campana.query.order_by(Campana.creado_en.desc()).all()

    # ── Intentar con API de Anthropic si hay clave configurada ──
    api_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()

    if api_key:
        try:
            import urllib.request as urlreq
            segmentos_info = stats['por_segmento']
            campanas_resumen = [
                f"{c.nombre} (segmento: {c.segmento_objetivo}, canal: {c.canal}, ROI: {c.roi}%, estado: {c.estado})"
                for c in campanas_all
            ]
            system_prompt = f"""Eres FinancuerAI, el asistente financiero inteligente de BancoMexicoFinance. Eres experto en análisis de clientes bancarios, segmentación, retención y campañas de marketing financiero.

DATOS REALES DEL SISTEMA:
- Total de clientes: {stats['total']}
- Clientes en riesgo de abandono (score ≥ 0.6): {stats['en_riesgo']}
- Ingreso mensual promedio: ${stats['ingreso_promedio']:,.0f} MXN
- Distribución por segmento: {segmentos_info}
- Top clientes en riesgo: {', '.join(riesgo_nombres) if riesgo_nombres else 'ninguno crítico'}
- Canales preferidos: {canales_info}
- Campañas: {'; '.join(campanas_resumen) if campanas_resumen else 'Sin campañas'}

INSTRUCCIONES:
- Responde SIEMPRE en español, profesional y directo
- Usa los datos reales del sistema
- Máximo 3 párrafos cortos
- Da recomendaciones concretas y accionables"""

            req_body = json.dumps({
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 800,
                "system": system_prompt,
                "messages": [{"role": "user", "content": mensaje}]
            }).encode("utf-8")

            req = urlreq.Request(
                "https://api.anthropic.com/v1/messages",
                data=req_body,
                headers={
                    "Content-Type": "application/json",
                    "anthropic-version": "2023-06-01",
                    "x-api-key": api_key
                },
                method="POST"
            )
            with urlreq.urlopen(req, timeout=20) as resp:
                result = json.loads(resp.read().decode("utf-8"))
                respuesta = result["content"][0]["text"]
                return jsonify({"respuesta": respuesta, "fuente": "api"})
        except Exception:
            pass  # Cae al motor local

    # ── Motor de IA Local (siempre funciona, 100% gratuito) ──
    respuesta = respuesta_ia_local(mensaje, stats, riesgo_nombres, canales_info, campanas_all)
    return jsonify({"respuesta": respuesta, "fuente": "local"})


# ─── Inicialización ────────────────────────────────────────────────────────────

def seed_data():
    if Usuario.query.count() > 0:
        return
    admin = Usuario(nombre="Admin BancoMexicoFinance", email="admin@bancomexicofinance.mx", rol="admin")
    admin.set_password("nexus2024")
    analista = Usuario(nombre="Ana García", email="ana@bancomexicofinance.mx", rol="analista")
    analista.set_password("analista123")
    db.session.add_all([admin, analista])

    nombres = [
        "Carlos Mendoza","María López","Juan Torres","Laura Sánchez","Pedro Ramírez",
        "Sofía Hernández","Roberto Díaz","Elena Martínez","Andrés Flores","Carmen Ruiz",
        "Miguel Ángel Castro","Patricia Morales","Francisco Jiménez","Rosa Guzmán","Luis Reyes",
        "Ana Paula Vega","Sergio Romero","Gabriela Cruz","Enrique Méndez","Claudia Guerrero",
        "Alejandro Muñoz","Valentina Ortiz","Ricardo Navarro","Diana Ramos","Fernando Aguilar",
        "Mariana Vargas","Eduardo Castillo","Lucía Herrera","Arturo Medina","Natalia Pedraza",
        "Jorge Ávila","Paola Cervantes","Humberto Lara","Verónica Salinas","Óscar Espinoza",
        "Itzel Domínguez","Manuel Pizarro","Sandra Ocampo","Raúl Villanueva","Irene Montes",
        "Gustavo Ríos","Adriana Cárdenas","Ernesto Bustos","Alicia Fuentes","César Treviño",
        "Mónica Ibáñez","Javier Gallegos","Elsa Quiroga","Víctor Acosta","Gloria Pacheco",
        "Daniel Soto","Rebeca Núñez","Iván Leiva","Fabiola Bravo","Salvador Mata",
        "Karla Solís","Rogelio Ponce","Beatriz Estrada","Mauricio Leal","Norma Ángeles",
        "Aarón Zúñiga","Leticia Palma","Benjamín Tapia","Esther Peña","Gilberto Velasco",
        "Yolanda Robledo","Héctor Meza","Concepción Barrera","Rolando Navarrete","Silvia Cano",
        "Braulio Arroyo","Lorena Chávez","Emigdio Prieto","Catalina Andrade","Fidel Córdoba",
        "Marisol Delgado","Leandro Esquivel","Cecilia Montoya","Rubén Zavala","Eugenia Durán",
        "Alejandra Infante","Nicolás Padilla","Verónica Nájera","Patricio Saavedra","Esperanza Téllez",
        "Armando Becerra","Lourdes Carrillo","Maximiliano Rosales","Pilar Vázquez","Octavio Mejía",
        "Berenice Segura","Aurelio Sandoval","Liliana Campos","Pompeyo Alvarado","Graciela Molina",
        "Teodoro Juárez","Alondra Palacios","Ignacio Aranda","Amparo Suárez","Baldomero Cortés",
        "Yazmin Ibarra","Ezequiel Quiñones","Dolores Fuentes","Primitivo Lozano","Monserrat Olvera",
        "Wilfredo Garza","Xóchitl Zamora","Clemente Osorio","Reyna Trujillo","Sigifredo Heredia",
        "Fernanda Contreras","Cirilo Mendieta","Úrsula Elizondo","Plácido Santana","Jacqueline Moreno",
        "Arnulfo Camacho","Miriam Gutiérrez","Esteban Serrano","Faustina Reyna","Tiburcio Rangel",
        "Samantha Escobedo","Hipolito Villafuerte","Zarahi Trejo","Bonifacio Solano","Adrián Galindo",
        "Daniela Perea","Aurelio Cervera","Tania Orozco","Genaro Lira","Edith Cardona",
        "Fidencio Bermúdez","Xiomara Mendívil","Celestino Aguirre","Isidra Robles","Pantaleón Vela",
        "Alejandra Huerta","Vidal Coronel","Brenda Tovar","Evaristo Guerrero","Ximena Paredes",
        "Calixto Arenas","Nadia Olmedo","Macario Fuentes","Ileana Barrios","Tiburcio Cabrera",
    ]
    ciudades = ["Ciudad de México","Guadalajara","Monterrey","Puebla","Tijuana","León","Mérida","Querétaro"]
    ocupaciones = ["Médico","Ingeniero","Empresario","Contador","Maestro","Abogado","Diseñador","Vendedor","Empleado","Freelancer"]
    canales = ["digital","sucursal","móvil","telefónico"]

    # Distribucion controlada: 80 Medio + 45 En Riesgo + 12 Premium + 13 resto
    random.seed(42)
    for i, nombre in enumerate(nombres):
        if i < 80:
            # Segmento "Medio": score 35-54 → ingreso 10k-29k, trans 10-19, score<650, antig 24+
            ingreso = random.uniform(10000, 29000)
            score_c = random.randint(500, 640)
            num_trans = random.randint(10, 19)
            num_prod = random.randint(2, 3)
            antig = random.randint(24, 59)
        elif i < 125:
            # Segmento "En Riesgo": ingreso bajo, score bajo, pocas transacciones
            ingreso = random.uniform(4000, 9000)
            score_c = random.randint(450, 530)
            num_trans = random.randint(0, 4)
            num_prod = random.randint(1, 2)
            antig = random.randint(1, 20)
        elif i < 137:
            # Segmento "Premium": ingreso alto, score alto
            ingreso = random.uniform(85000, 200000)
            score_c = random.randint(750, 820)
            num_trans = random.randint(20, 40)
            num_prod = random.randint(3, 5)
            antig = random.randint(48, 120)
        else:
            # Resto variado
            ingreso = random.uniform(30000, 80000)
            score_c = random.randint(600, 750)
            num_trans = random.randint(10, 25)
            num_prod = random.randint(2, 4)
            antig = random.randint(24, 90)
        c = Cliente(
            nombre=nombre,
            email=nombre.lower().replace(" ", ".") + "@gmail.com",
            edad=random.randint(22, 65),
            genero=random.choice(["M", "F"]),
            ciudad=random.choice(ciudades),
            ocupacion=random.choice(ocupaciones),
            ingreso_mensual=round(ingreso, 2),
            saldo_cuenta=round(ingreso * random.uniform(0.5, 5), 2),
            score_credito=score_c,
            num_productos=num_prod,
            antiguedad_meses=antig,
            num_transacciones_mes=num_trans,
            monto_promedio_transaccion=round(random.uniform(200, 8000), 2),
            tiene_hipoteca=random.random() > 0.6,
            tiene_inversion=random.random() > 0.5,
            tiene_seguro=random.random() > 0.4,
            canal_preferido=random.choice(canales),
        )
        calcular_segmento(c)
        db.session.add(c)

    camps = [
        Campana(nombre="Retención Q1 2026", segmento_objetivo="En Riesgo", canal="email",
                presupuesto=15000, clientes_alcanzados=45, conversiones=8, roi=214.0, estado="completada"),
        Campana(nombre="Cross-sell Premium", segmento_objetivo="Premium", canal="móvil",
                presupuesto=30000, clientes_alcanzados=12, conversiones=7, roi=250.0, estado="activa"),
        Campana(nombre="Activación Digital", segmento_objetivo="Medio", canal="push",
                presupuesto=8000, clientes_alcanzados=80, conversiones=18, roi=187.5, estado="activa"),
    ]
    db.session.add_all(camps)
    db.session.commit()
    print("[OK] Base de datos inicializada con datos de prueba.")


# ═══════════════════════════════════════════════════════════════════════════════
# ACTIVIDAD: Notificaciones push y acceso a características nativas desde la PWA
# Alumna: Noemi Judith Guerrero Villanueva · Matrícula 202204010
#
# Dónde está cada paso del procedimiento:
#   1) Explicación del flujo de suscripción push   -> templates/notificaciones_nativas.html
#   2) Permiso + notificación de prueba            -> static/js/push-nativo.js
#                                                     + static/sw.js (eventos push)
#                                                     + /api/push/* (este bloque)
#   3) Característica nativa: geolocalización      -> static/js/push-nativo.js
#   4) Comportamiento al conceder / negar permisos -> static/js/push-nativo.js
#
# Lo que se agregó en el servidor:
#   - /notificaciones-nativas   página de la actividad
#   - /api/push/clave           devuelve la clave pública VAPID
#   - /api/push/suscribir       guarda la suscripción que genera el navegador
#   - /api/push/enviar-prueba   manda un push real a las suscripciones guardadas
# ═══════════════════════════════════════════════════════════════════════════════

try:
    from pywebpush import webpush, WebPushException   # pip install pywebpush
except ImportError:                                    # la app sigue funcionando sin la librería
    webpush = None
    WebPushException = Exception

PUSH_SUBS_FILE = os.path.join(BASE_DIR, "instance", "push_subscriptions.json")
VAPID_PRIVATE_FILE = os.path.join(BASE_DIR, "instance", "vapid_private.pem")
VAPID_PUBLIC_FILE = os.path.join(BASE_DIR, "instance", "vapid_public.txt")


def leer_suscripciones():
    if not os.path.exists(PUSH_SUBS_FILE):
        return []
    with open(PUSH_SUBS_FILE, encoding="utf-8") as f:
        return json.load(f)


def guardar_suscripciones(lista):
    with open(PUSH_SUBS_FILE, "w", encoding="utf-8") as f:
        json.dump(lista, f, indent=2)


@app.route("/notificaciones-nativas")
@login_required
def notificaciones_nativas():
    return render_template("notificaciones_nativas.html")


@app.route("/api/push/clave")
@login_required
def api_push_clave():
    # La clave pública VAPID identifica a mi servidor ante el servicio push del navegador.
    with open(VAPID_PUBLIC_FILE, encoding="utf-8") as f:
        return jsonify({"publicKey": f.read().strip()})


@app.route("/api/push/suscribir", methods=["POST"])
@login_required
def api_push_suscribir():
    sub = request.get_json(silent=True) or {}
    if not sub.get("endpoint"):
        return jsonify({"ok": False, "error": "Suscripción inválida"}), 400
    lista = [s for s in leer_suscripciones() if s.get("endpoint") != sub["endpoint"]]
    lista.append(sub)
    guardar_suscripciones(lista)
    return jsonify({"ok": True, "total": len(lista)})


@app.route("/api/push/enviar-prueba", methods=["POST"])
@login_required
def api_push_enviar_prueba():
    if webpush is None:
        return jsonify({"ok": False, "error": "Falta instalar pywebpush"}), 500
    payload = json.dumps({
        "title": "FinancePWA · Notificación de prueba",
        "body": "Este push lo envió el servidor Flask a tu dispositivo.",
        "url": "/notificaciones-nativas",
    })
    enviados, fallidos, vigentes = 0, 0, []
    for sub in leer_suscripciones():
        try:
            webpush(
                subscription_info=sub,
                data=payload,
                vapid_private_key=VAPID_PRIVATE_FILE,
                vapid_claims={"sub": "mailto:202204010@utacapulco.edu.mx"},
            )
            enviados += 1
            vigentes.append(sub)
        except WebPushException as e:
            fallidos += 1
            # 404/410 = el usuario canceló la suscripción: se elimina de la lista
            if getattr(e, "response", None) is not None and e.response.status_code in (404, 410):
                continue
            vigentes.append(sub)
    guardar_suscripciones(vigentes)
    return jsonify({"ok": True, "enviados": enviados, "fallidos": fallidos})


# ─── Rutas de la PWA (Progressive Web App) ─────────────────────────────────────
# Service Worker: se sirve desde la raíz "/sw.js" (y no desde "/static/sw.js")
# para que su "scope" cubra TODA la aplicación y no solo la carpeta static.
@app.route("/sw.js")
def service_worker():
    response = send_from_directory(
        os.path.join(app.static_folder), "sw.js"
    )
    response.headers["Content-Type"] = "application/javascript"
    response.headers["Service-Worker-Allowed"] = "/"
    response.headers["Cache-Control"] = "no-cache"
    return response


# Manifest: metadatos de la app (nombre, iconos, colores, URL de inicio)
# que permiten instalarla en la pantalla de inicio del dispositivo.
@app.route("/manifest.json")
def manifest():
    response = send_from_directory(
        os.path.join(app.static_folder), "manifest.json"
    )
    response.headers["Content-Type"] = "application/manifest+json"
    return response


# Página de respaldo mostrada por el Service Worker cuando no hay
# conexión y el recurso solicitado no está en caché.
@app.route("/offline")
def offline():
    return render_template("offline.html")


# ─── PWA completa: splash, inicio, /health y arranque para hosting ─────────────
from pwa_completa import registrar_pwa_completa
registrar_pwa_completa(app, db, get_stats, seed_data)


if __name__ == "__main__":
    os.makedirs("instance", exist_ok=True)
    with app.app_context():
        db.create_all()
        seed_data()
    app.run(debug=True, port=5000)
