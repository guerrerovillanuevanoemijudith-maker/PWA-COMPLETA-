#!/bin/bash
# ─── BancoIAFinance - Actualización de Contenedores sin downtime ───────────────
# Alumno: Guerrero Villanueva Noemi Judith

echo "═══════════════════════════════════════════"
echo "  BancoIAFinance - Actualización de contenedores"
echo "═══════════════════════════════════════════"

# 1. Descargar últimas imágenes base
echo "[1/4] Descargando últimas imágenes base..."
docker compose pull

# 2. Reconstruir imagen de la app
echo "[2/4] Reconstruyendo imagen de la aplicación..."
docker compose build --no-cache flask_app

# 3. Reiniciar con zero-downtime (rolling update)
echo "[3/4] Actualizando contenedores..."
docker compose up -d --no-deps flask_app

# 4. Verificar estado
echo "[4/4] Verificando estado de los contenedores..."
sleep 10
docker compose ps

echo ""
echo "═══════════════════════════════════════════"
echo "  Logs recientes de la app:"
docker compose logs --tail=20 flask_app
echo "═══════════════════════════════════════════"
