#!/bin/bash
# ─── BancoIAFinance - Inicialización de Certificados SSL (Let's Encrypt) ──────
# Ejecutar UNA VEZ en el servidor VPS/GCP después del primer docker-compose up
# Alumno: Guerrero Villanueva Noemi Judith

DOMAIN="guerrerovillanuevanoemi judith-org.com"
EMAIL="noemi@guerrerovillanuevanoemi judith-org.com"

echo "═══════════════════════════════════════════════════"
echo "  BancoIAFinance - Configuración SSL / HTTPS"
echo "  Dominio: $DOMAIN"
echo "═══════════════════════════════════════════════════"
echo ""

# 1. Levantar solo nginx en modo HTTP primero
echo "[1/3] Levantando Nginx en modo HTTP..."
docker compose up -d nginx
sleep 5

# 2. Obtener certificado Let's Encrypt
echo "[2/3] Solicitando certificado SSL a Let's Encrypt..."
docker compose run --rm certbot certonly \
  --webroot \
  --webroot-path=/var/www/certbot \
  --email "$EMAIL" \
  --agree-tos \
  --no-eff-email \
  -d "$DOMAIN" \
  -d "www.$DOMAIN"

if [ $? -eq 0 ]; then
    echo "✓ Certificado SSL obtenido correctamente"
else
    echo "✗ Error al obtener certificado. Verifica que el dominio apunte a este servidor."
    exit 1
fi

# 3. Reiniciar todos los servicios con HTTPS habilitado
echo "[3/3] Reiniciando todos los servicios con HTTPS..."
docker compose restart nginx
docker compose up -d

echo ""
echo "═══════════════════════════════════════════════════"
echo "  ✓ HTTPS configurado correctamente"
echo "  Visita: https://$DOMAIN"
echo "═══════════════════════════════════════════════════"
