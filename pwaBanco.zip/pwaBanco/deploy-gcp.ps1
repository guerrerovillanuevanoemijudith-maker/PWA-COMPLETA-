# ─── BancoIAFinance - Deploy Automático a Google Cloud Platform ────────────────
# Script PowerShell para Windows / Visual Studio Code
# Alumno: Guerrero Villanueva Noemi Judith
# Ejecutar desde VS Code Terminal (PowerShell) con: .\deploy-gcp.ps1

param(
    [string]$ProjectId = "bancoiafinance-proyecto",
    [string]$Region    = "us-central1",
    [string]$Service   = "bancoiafinance"
)

Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║   BancoIAFinance - Deploy GCP (Windows)  ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# ── Verificar herramientas instaladas ─────────────────────────────────────────
Write-Host "[1/7] Verificando herramientas..." -ForegroundColor Yellow

if (-not (Get-Command "gcloud" -ErrorAction SilentlyContinue)) {
    Write-Host "ERROR: gcloud no está instalado." -ForegroundColor Red
    Write-Host "Descarga Google Cloud SDK desde: https://cloud.google.com/sdk/docs/install" -ForegroundColor White
    exit 1
}

if (-not (Get-Command "docker" -ErrorAction SilentlyContinue)) {
    Write-Host "ERROR: Docker no está instalado." -ForegroundColor Red
    Write-Host "Descarga Docker Desktop desde: https://www.docker.com/products/docker-desktop" -ForegroundColor White
    exit 1
}

Write-Host "✓ gcloud encontrado: $(gcloud version --format='value(Google Cloud SDK)' 2>$null)" -ForegroundColor Green
Write-Host "✓ docker encontrado" -ForegroundColor Green

# ── Autenticación en GCP ──────────────────────────────────────────────────────
Write-Host ""
Write-Host "[2/7] Autenticando en Google Cloud Platform..." -ForegroundColor Yellow
gcloud auth login --launch-browser
gcloud config set project $ProjectId
Write-Host "✓ Proyecto configurado: $ProjectId" -ForegroundColor Green

# ── Habilitar APIs necesarias ─────────────────────────────────────────────────
Write-Host ""
Write-Host "[3/7] Habilitando APIs de GCP..." -ForegroundColor Yellow
gcloud services enable `
    run.googleapis.com `
    cloudbuild.googleapis.com `
    containerregistry.googleapis.com `
    --project=$ProjectId

Write-Host "✓ APIs habilitadas" -ForegroundColor Green

# ── Configurar Docker para GCP Container Registry ─────────────────────────────
Write-Host ""
Write-Host "[4/7] Configurando Docker con GCR..." -ForegroundColor Yellow
gcloud auth configure-docker --quiet
Write-Host "✓ Docker configurado para GCR" -ForegroundColor Green

# ── Construir imagen Docker ───────────────────────────────────────────────────
Write-Host ""
Write-Host "[5/7] Construyendo imagen Docker optimizada..." -ForegroundColor Yellow
$ImageTag = "gcr.io/$ProjectId/${Service}:latest"
docker build --target production -t $ImageTag ./app
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Fallo en la construcción de la imagen" -ForegroundColor Red
    exit 1
}
Write-Host "✓ Imagen construida: $ImageTag" -ForegroundColor Green

# ── Push al Container Registry ────────────────────────────────────────────────
Write-Host ""
Write-Host "[6/7] Subiendo imagen a Google Container Registry..." -ForegroundColor Yellow
docker push $ImageTag
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Fallo al subir la imagen" -ForegroundColor Red
    exit 1
}
Write-Host "✓ Imagen subida a GCR" -ForegroundColor Green

# ── Deploy a Cloud Run ────────────────────────────────────────────────────────
Write-Host ""
Write-Host "[7/7] Desplegando en Cloud Run..." -ForegroundColor Yellow
gcloud run deploy $Service `
    --image=$ImageTag `
    --region=$Region `
    --platform=managed `
    --allow-unauthenticated `
    --port=5000 `
    --memory=512Mi `
    --cpu=1 `
    --min-instances=1 `
    --max-instances=3 `
    --set-env-vars="FLASK_ENV=production,SECRET_KEY=bancoiafinance-gcp-prod-2024" `
    --project=$ProjectId

if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Fallo en el despliegue" -ForegroundColor Red
    exit 1
}

# ── Obtener URL del servicio ──────────────────────────────────────────────────
Write-Host ""
$ServiceUrl = gcloud run services describe $Service `
    --region=$Region `
    --format="value(status.url)" `
    --project=$ProjectId

Write-Host "╔══════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║           ✓ DEPLOY EXITOSO EN GCP                   ║" -ForegroundColor Green
Write-Host "╠══════════════════════════════════════════════════════╣" -ForegroundColor Green
Write-Host "║  URL del servicio: $ServiceUrl" -ForegroundColor White
Write-Host "║  Proyecto: $ProjectId" -ForegroundColor White
Write-Host "║  Región: $Region" -ForegroundColor White
Write-Host "╚══════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""
Write-Host "Abre la consola GCP en: https://console.cloud.google.com" -ForegroundColor Cyan

Write-Host "Version: 1.0.0 | Release: Commit 40" -ForegroundColor Gray
