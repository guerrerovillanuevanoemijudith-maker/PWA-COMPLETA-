# API Routes - Noemi Judith
from flask import Blueprint, jsonify

api = Blueprint('api', __name__)

@api.route('/api/v1/clientes', methods=['GET'])
def get_clientes():
    return jsonify({"status": "ok", "data": []})

@api.route('/api/v1/campanas', methods=['GET'])
def get_campanas():
    return jsonify({"status": "ok", "data": []})
