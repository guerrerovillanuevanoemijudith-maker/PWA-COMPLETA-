#!/bin/bash

# ============================================================================
# BancoFinancesChat - Script de Ejecución con Docker
# ============================================================================

clear

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║      🏦 BANCOFINANCESCHAT - Sistema de IA Financiero          ║"
echo "║        Ejecutando con Docker en http://localhost:5000         ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

cd "$(dirname "$0")"

# Verificar que Docker esté instalado
if ! command -v docker &> /dev/null; then
    echo "❌ Error: Docker no está instalado"
    echo "Por favor instala Docker desde: https://www.docker.com/get-started"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Error: Docker Compose no está instalado"
    exit 1
fi

echo "✅ Docker y Docker Compose detectados"
echo ""
echo "🚀 Iniciando servicios con Docker Compose..."
echo ""

docker-compose up --build

if [ $? -ne 0 ]; then
    echo ""
    echo "❌ Error al iniciar Docker Compose"
    exit 1
fi
