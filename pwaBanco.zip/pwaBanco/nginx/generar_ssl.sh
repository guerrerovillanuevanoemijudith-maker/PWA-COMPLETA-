#!/bin/bash
# ── Genera certificado SSL auto-firmado para desarrollo ───────────────────────
# En producción usa: certbot certonly --standalone -d TU_DOMINIO

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$SCRIPT_DIR/ssl"

echo "Generando certificado SSL auto-firmado..."
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout "$SCRIPT_DIR/ssl/key.pem" \
  -out "$SCRIPT_DIR/ssl/cert.pem" \
  -subj "/C=MX/ST=Guerrero/L=Acapulco/O=BancoIAFinance/CN=localhost" \
  -addext "subjectAltName=DNS:localhost,IP:127.0.0.1"

echo "✅ Certificado generado en nginx/ssl/"
echo "   cert.pem  → certificado público"
echo "   key.pem   → clave privada (NO subas esto a Git)"
